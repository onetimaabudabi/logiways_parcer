import pandas as pd
import numpy as np
import re
from datetime import datetime, timedelta
import json
import os
from get_tables_sites import get_tables_pdf, get_shedule_EuroSib
import pdfplumber
from pathlib import Path
import requests

# =============================
# type_route - тип маршрута(морской фрахт или ЖД)
# start_point pol - POL (Port of Loading) – порт отправления
# end_point pod - POD (Port of Discharge) – порт выгрузки
# transshipment - Порт перевалки – терминал в порту (трансшипмент)
# final_destination destination - Пункт назначения drop
# weight_limit - Размер контейнеров
# container_type - Тип контейнера (20DC, 40HC и тд.)
# cost - Тариф
# conditions :
# own - SOC/COC – чей контейнер (Carrier’s Own Container / Shipper’s Own Container)
# security - охрана

# =============================

security_20 = 0
security_40 = 0

old_port_dict = {
    "SHA":"Shanghai",
    "NGB":"Ningbo",
    "QD":"Qingdao",
    "TPE":"Taipei",
    "SIN":"Singapore",
    "HKH":"Hong Kong",
    "SYD":"Sydney",
    "MEL":"Melbourne",
    "BNE":"Brisbane",
    "SZ":"Shenzhen",
    "CNX":"Chiang Mai",
    "HKT":"Koh Samui",
    "CNX":"Chiang Mai",
    "ВМРП": "Владивосток",
    "Врангель": "Находка"
}

border_dict = {
    "Erlian": "Эрлан",
    "Manzhouli": "Маньчжурия",
    "Horgos": "Хоргос"

}

currency_dict = {
    "$": "USD",
    "руб": "RUB"
}

port_dict = {
    "Shanghai": "Шанхай",
    "Kolyadichy": "Колядичи",
    "Datong": "Датун",
    "Jiaxing": "Цзясин",
    "Taizhou": "Тайчжоу",
    "Xian": "Сиань",
    "Luoyang": "Лоян",
    "Zhumadian": "Чжумадянь",
    "Kunming": "Куньмин",
    "Chaoshan": "Гуандун",
    "Hengshui": "Хэншуй",
    "Tai 'An": "Тайань",
    "Quzhou": "Цюйчжоу",
    "Rui'An": "Руиан",
    "Lianyun'Gang": "Ляньюньган",
    "Bazhou": "Бачжоу",
    "Lanxi": "Ланьси",
    "Yiwu": "Иу",
    "Hohhot": "Хух-Хото",
    "Pinghunan": "Пхеньян",
    "Fuzhou": "Фучжоу",
    "Ganzhou": "Ганьчжоу",
    "Taiyuan": "Тайюань",
    "Hefei": "Хэфэй",
    "Langfang": "Ланфан",
    "Wuxi": "Уси",
    "Taiwan": "Тайвань",
    "Ho Chiminh": "Хошимин",
    "Yuyao": "Юяо",
    "Japan": "Япония",
    "Jebel Ali": "Джабаль-Али",
    "Shaoxing": "Шаосинь",
    "Lianyungang": "Ляньюньган",
    "Changshu": "Чанчжоу",
    "Kunshan": "Куньшань",
    "Changzhou": "Чанчжоу",
    "Shaoxing": "Шаосинь",
    "Hangzhou": "Ханчжоу",
    "Lianyungang": "Ляньюньган",
    "Shunde": "Шуньдэ",
    "Huizhou": "Хуэйчжоу",
    "Jiangmen": "Цзянмэнь",
    "Zhuhai": "Чжухай",
    "Zhaoqing": "Чжаоцин",
    "Spb": "Санкт-Петербург",
    "Nanhsa": "Наньша",
    "Novorossiysk": "Новороссийск",
    "Suzhou": "Сучжоу",
    "Jinhua": "Цзиньхуа",
    "Wenzhou": "Вэньчжоу",
    "Suzhou": "Сучжоу",
    "Ningbo": "Нинбо",
    "Yuyao": "Юяо",
    "Cixi": "Цыси",
    "Qingdao": "Циндао",
    "Linyi": "Линьи",
    "Tianjin": "Тяньцзинь",
    "Cangzhou": "Цанчжоу",
    "Jinan": "Цзинань",
    "Weihai": "Вэйхай",
    "Weifang": "Вэйфан",
    "Yantai": "Яньтай",
    "Dongying": "Дунъин",
    "Shijiazhuang": "Шицзячжуан",
    "Beijing": "Пекин",
    "Guangzhou": "Гуанчжоу",
    "Shenzhen": "Шэньчжэнь",
    "Dongguan": "Дунгуань",
    "Foshan": "Фошань",
    "Zhongshan": "Чжуншань",
    "Chaozhou": "Чаочжоу",
    "Shantou": "Шаньтоу",
    "Ningbo": "Нинбо",
    "Guangzhou": "Гуанчжоу",
    "Wuhan": "Ухань",
    "Chengdu": "Чэнду",
    "Chongqing": "Чунцин",
    "Qingdao": "Циндао",
    "Quingdao": "Циндао",
    "Taipei": "Тайбэй",
    "Singapore": "Сингапур",
    "Shantou": "Шаньтоу",
    "Hong Kong": "Гонконг",
    "Sydney": "Сидней",
    "Melbourne": "Мельбурн",
    "Brisbane": "Брисбен",
    "Shenzhen": "Шэньчжэнь",
    "Chiang Mai": "Чиангмай",
    "Koh Samui": "Ко Самуи",
    "Rizhao": "Жичжао",
    "Xiamen": "Ксиамень",
    "Tianjin": "Тяньзинь",
    "Xingang": "Ксинганг",
    "Xingang (Tianjin)": "Ксинганг",
    "Tianjin (Xingang)": "Ксинганг",
    "Shenzhen (Yantian, Shekou)": "Шэньчжэнь",
    "Dalian": "Далянь",
    "Taisang": "Тайсанг",
    "Shekou": "Шеньжень",
    "Nansha": "Наньша",
    "Huangpu": "Хуанпу",
    "SHA":"Шанхай",
    "NGB":"Нинбо",
    "QD":"Циндао",
    "TPE":"Тайбэй",
    "SIN":"Сингапур",
    "HKH":"Гонконг",
    "SYD":"Сидней",
    "MEL":"Мельбурн",
    "BNE":"Брисбен",
    "SZ":"Шэньчжэнь",
    "CNX":"Чиангмай",
    "HKT":"Ко Самуи",
    "ВМРП": "Владивосток ВМРП",
    "ВМКТ": "Владивосток ВМКТ",
    "Врангель": "Находка",
    "LOS ANGELES": "Лос-Анджелес",
    "LONG BEACH": "Лонг-Бич",
    "OAKLAND": "Окленд",
    "SEATTLE": "Сиэтл",
    "TACOMA": "Такома",
    "NEW YORK": "Нью-Йорк",
    "NEW  YORK": "Нью-Йорк",
    "NORFOLK": "Норфолк",
    "SAVANNAH": "Саванна",
    "CHARLESTON": "Чарлстон",
    "MIAMI": "Майами",
    "HOUSTON": "Хьюстон",
    "MOBILE": "Мобил",
    "TAMPA": "Тампа",
    "TORONTO": "Торонто",
    "MONTREAL": "Монреаль",
    "SPB": "Санкт-Петербург",
    "NOVO": "Новороссийск",
    "Nanjing": "Нанкин",
    "Taicang": "Тайцан",
    "Jakarta": "Джакарта",
    "Busan": "Пусан",
    "Port Klang": "Порт-Кланг",
    "Laem Chabang": "Лаем-Чабанг",
    "Ho Chi Minh": "Хошимин",
    "Yantian": "Яньтянь",
    "ALGER": "Алжир",
    "PORT SAID WEST": "Порт-Саид",
    "Novorossiysk": "Новороссийск",
    "Gebze": "Гебзе",
    "Gebze (Beldeport)": "Гебзе",
    "Ambarli": "Амбарли",
    "Ambarli (Kumport)": "Амбарли",
    "Mersin": "Мерсин",
    "Izmir": "Измир",
    "Sanko": "Санко",
    "Iskenderun": "Искендерун",
    "Alexandria": "Александрия",
    "El Dekheila": "Эль-Декхейла",
    "Damietta": "Думьят",
    "Ashdod": "Ашдод",
    "Haifa": "Хайфа",
    "Aleksandria": "Александрия",
    "Misurata": "Мисурата",
    "Benghazi": "Бенгази",
    "Bengazi": "Бенгази",
    "Barcelone": "Барселона",
    "Barcelona": "Барселона",
    "Valencia": "Валенсия",
    "Beirut": "Бейрут",
    "Latakia": "Латакия",
    "Jeddah": "Джидда",
    "Nhava Sheva": "Нава-Шева",
    "Mundra": "Мундра",
    "Haiphong": "Хайфон",
    "Hochiminh": "Хошимин",
    "Bangkok": "Бангкок",
    "Chennai": "Ченнаи",
    "Cochin": "Кочин",
    "Kolkata": "Колката",
    "Surabaya": "Сурабая",
    "Semarang": "Семаранг",
    "Pasir Gudang": "Пасир-Гуданг",
    "Kaohsiung": "Гаосюн",
    "Taichung": "Тайчжун",
    "Taichung": "Тайчжун",
    "Keelung": "Килунг",
    "Nagoya": "Нагоя",
    "Tokyo": "Токио",
    "Yokohama": "Иокогама",
    "Osaka": "Осака",
    "Karachi": "Карачи",
    "Chittagong": "Читтагонг",
    "Sihanoukville": "Сиануквиль",
    "Yangon": "Янгон",
    "Vostochniy": "Находка",
    "Zhengzhou": "Чжэнчжоу",
    "Xi‘An": "Сиань"
 }

route_dict = {
    "MORSKOY FRAGHT":"Морской фрахт",
    "ZHDD":"ЖД",
    "VMPP":"ВМРП",
    "VPRGEL":"Врангель",
    "Терминал Врангель":"Врангель"
}

country_dict = {
    "Россия": [
        "All",
        "Владивосток", 
        "Владивосток ВМРП", 
        "Владивосток ВМКТ", 
        "Шушары",
        "Находка", 
        "Ворсино",
        "Самара",
        "Москва",
        "Селятино",
        "Электроугли",
        "Иркутск",
        "Санкт-Петербург", 
        "Новосибирск", 
        "Екатеринбург", 
        "Казань", 
        "Нижний Новгород", 
        "Тольятти", 
        "Красноярск", 
        "Ростов-на-Дону", 
        "Челябинск", 
        "Пенза",
        "Новороссийск", 
        "Мурманск",
        "Уссурийск",
        "Омск",
        "Нижнекамск",
        "Тюмень",
        "Ижевск",
        "Пермь",
        "Рязань",
        "Казань",
        "Артем",
        "Белый Раст",
        "Ховрино",
        "Ульяновск"
    ],
    "Белорусь": [
        "Минск",
        "Колядичи"
    ],
    "США": [
        "Лос-Анджелес", 
        "Лонг-Бич", 
        "Нью-Йорк",
        "Окленд",
        "Такома",
        "Норфолк",
        "Хьюстон",
        "Мобил", 
        "Саванна", 
        "Чарлстон",
        "Тампа",
        "Сиэтл", 
        "Джексонвилл", 
        "Майами", 
        "Портленд",
        "Побережье Мексиканского залива США",
        "Восточное побережье США",
        "Западное побережье США"
    ],
    "Канада": [
        "Торонто",
        "Монреаль"
    ],
    "Китай": [
        "Шанхай",
        "Ланьси", 
        "Хэншуй",
        "Куньмин",
        "Чжумадянь",
        "Лоян",
        "Ляньюньган",
        "Тайчжоу",
        "Сиань",
        "Гуандун",
        "Тайань",
        "Цюйчжоу",
        "Руиан",
        "Цзясин",
        "Датун",
        "Фучжоу",
        "Пхеньян",
        "Бачжоу",
        "Тайюань",
        "Иу",
        "Ганьчжоу",
        "Ланфан",
        "Уси",
        "Юяо",
        "Шаосинь",
        "Ляньюньган",
        "Чанчжоу",
        "Куньшань",
        "Чанчжоу",
        "Шаосинь",
        "Ханчжоу",
        "Ляньюньган",
        "Шуньдэ",
        "Хуэйчжоу",
        "Цзянмэнь",
        "Чжухай",
        "Чжаоцин",
        "Чжэнчжоу",
        "Нинбо", 
        "Циндао",
        "Юяо",
        "Цыси",
        "Линьи",
        "Цанчжоу",
        "Дунгуань",
        "Шанхай",
        "Сучжоу",
        "Нинбо",
        "Юяо",
        "Цыси",
        "Циндао",
        "Линьи",
        "Тяньцзинь",
        "Цанчжоу",
        "Цзинань",
        "Вэйхай",
        "Вэйфан",
        "Яньтай",
        "Дунъин",
        "Шицзячжуан",
        "Цзянмэнь",
        "Пекин",
        "Гуанчжоу",
        "Шэньчжэнь",
        "Дунгуань",
        "Чжуншань",
        "Чаочжоу", 
        "Тяньцзинь", 
        "Далянь", 
        "Циндао", 
        "Ксиамень", 
        "Фошань",
        "Гонконг",
        "Сямынь",
        "Жичжао",
        "Ксинганг",
        "Тайсанг",
        "Ксиамень",
        "Шеньжень",
        "Наньша",
        "Тяньзинь",
        "Нанкин",
        "Тайцан",
        "Яньтянь",
        "Ухань",
        "Чжухай",
        "Хуэйчжоу",
        "Гуанчжоу",
        "Хуанпу",
        "Чунцин",
        "Чэнду",
        "Шаньтоу",
        "Хэфэй",
        "Сучжоу",
        "Цзиньхуа",
        "Вэньчжоу"
    ],
    "Япония": [
        "Иокогама", 
        "Нагоя", 
        "Кобе", 
        "Тояма", 
        "Осака", 
        "Кавасаки", 
        "Тиба", 
        "Сакаи", 
        "Майдзуру", 
        "Омура",
        "Токио",
        "Япония"
    ],
    "Корея": [
        "Пусан", 
        "Инчхон", 
        "Кванъян", 
        "Ульсан", 
        "Пхохан", 
        "Мокпхо", 
        "Йосу", 
        "Кванджу", 
        "Чхонджу", 
        "Согвипхо"
    ],
    "Тайвань": [
        "Тайбэй",
        "Тайчжун", 
        "Килунг",
        "Гаосюн",
        "Тайвань"
    ],
    "Сингапур": [
        "Сингапур"
    ],
    "Австралия": [
        "Сидней", 
        "Мельбурн", 
        "Брисбен"
    ],
    "Таиланд": [
        "Чиангмай", 
        "Ко Самуи",
        "Лаем-Чабанг",
        "Бангкок"
    ],
    "Индонезия": [
        "Джакарта",
        "Сурабая",
        "Семаранг"
    ],
    "Малайзия": [
        "Порт-Кланг",
        "Пасир-Гуданг"
    ],
    "Вьетнам": [
        "Хошимин",
        "Хайфон"
    ],
    "Алжирская Народная Демократическая Республика": [
        "Алжир"
    ],
    "Египет": [
        "Порт-Саид",
        "Александрия",
        "Эль-Декхейла",
        "Думьят"
    ],
    "Турция": [
        "Гебзе",
        "Амбарли",
        "Мерсин",
        "Измир",
        "Санко",
        "Искендерун"
    ],
    "Ливия": [
        "Мисурата",
        "Бенгази",
    ],
    "Испания": [
        "Барселона",
        "Валенсия",
    ],
    "Ливан": [
        "Бейрут",
    ],
    "Сирия": [
        "Латакия",
    ],
    "Саудовская Аравия": [
        "Джидда",
    ],
    "Индия": [
        "Нава-Шева",
        "Мундра",
        "Ченнаи",
        "Кочин",
        "Колката"
    ],
    "Пакистан": [
        "Карачи"
    ],
    "Бангладеш": [
        "Читтагонг"
    ],
    "Камбоджа": [
        "Сиануквиль"
    ],
    "Мьянма": [
        "Янгон"
    ],
    "Израиль":[
        "Ашдод",
        "Хайфа"
    ],
    "Объединённые Арабские Эмираты":[
        "Джабаль-Али"
    ],
    "Монголия": [
        "Хух-Хото"
    ]
}

old_region_dict = {
    "USWC": "US West Coast",
    "USEC": "US East Coast",
    "USGC": "US Gulf Coast",
    "CANADA": "Canada",
    "МСК": "Moscow",
    "СПб": "St. Petersburg",
    "НСК": "Novosibirsk",
    "ЕКБ": "Ekaterinburg",
    "КЗ": "Kazan",
    "УФО": "Ufa",
    "Екатеринбург": "Ekaterinburg",
    "Санкт-Петербург": "St. Petersburg"
}

region_dict = {
    "USWC": "Западное побережье США",
    "Kolyadichy": "Колядичи",
    "USEC": "Восточное побережье США",
    "USGC": "Побережье Мексиканского залива США",
    "CANADA": "Канада",
    "МСК": "Москва",
    "Selyatino": "Селятино",
    "Shushary": "Шушары",
    "Elektrougli": "Электроугли",
    "Electrougli": "Электроугли",
    "СПБ": "Санкт-Петербург",
    "НСК": "Новосибирск",
    "ЕКБ": "Екатеринбург",
    "Yekaterinburg": "Екатеринбург",
    "Novosibirsk": "Новосибирск",
    "Irkutsk": "Иркутск",
    "Kazan": "Казань",
    "Ulyanovsk": "Ульяновск",
    "Togliatti": "Тольятти",
    "Kolyadichi": "Колядичи",
    "Hovrino": "Ховрино",
    "КЗ": "Казань",
    "УФО": "Уфа",
    "Bely Rast": "Белый Раст",
    "Shushary Logistik": "Санкт-Петербург",
    "Ekaterinburg": "Екатеринбург",
    "St. Petersburg": "Санкт-Петербург",
    "Spb Fct": "Санкт-Петербург",
    "Spb Fct/Plp": "Санкт-Петербург",
    "Spb Plp": "Санкт-Петербург",
    "Spb Ctsp": "Санкт-Петербург",
    "Novorossiysk(Nle)": "Новороссийск",
    "Ростов": "Ростов-на-Дону",
    "Moscow": "Москва",
    "Vorsino": "Ворсино",
    "St.Petersburg": "Санкт-Петербург",
    "Yekaterinbug": "Екатеринбург",
    "Saint Petersburg": "Санкт-Петербург",
    "Minsk": "Минск",
}

container_size_dict = {
    "20DC": "24",
    "20GP": "24",
    "20DC_28": "28",
    "20TK": "28",
    "20 Tank": "28",
    "20RF": "28",
    "40GP": "28",
    "40DV": "28",
    "40HQ": "28",
    "40HC": "28",
    "40RH": "30",
    "40RF": "30",
    "20OT": "30",
    "40OT": "28",
    "20FR": "35",
    "40FR": "45",
}

stations_dist = {
    "Тольятти": {"Тольятти"},
    "Владивосток": {"Мыс-Чуркин", "Угольная"},
    "Омск": {"Омск-Восточный"},
    "Нижнекамск": {"Нижнекамск"},
    "Нижний Новгород": {"Костариха"},
	"Пермь": {"Блочная"},
    "Красноярск": {"Базаиха"},
	"Иркутск": {"Батарейная"},
    "Москва": {"Станции московского узла", "Селятино", "Станциимосковского узла"},
    "Екатеринбург": {"Екатеринбург-Товарный"},
    "Челябинск": {"Челябинск-Грузовой"},
    "Ростов-на-Дону": {"Ростов-Товарный"},
    "Тюмень": {"Войновка"},
    "Ижевск": {"Позимь"},
    "Новосибирск": {"Чемской", "Мошково", "Клещиха"},
    "Казань": {"Лагерная"},
    "Санкт-Петербург": {"Шушары"},
    "Уссурийск": {"Уссурийск"},
    "Артем": {"Угловая"}
}

def get_city_station(station):
	for key,values in stations_dist.items():
		if station in values:
			return key
	return station

def get_country(city):
    for country, cities in country_dict.items():
        if city in cities:
            return country

def convert_date(date_str: str) -> str:
    # Словарь для преобразования названий месяцев
    months = {
        'january': '01', 'february': '02', 'march': '03',
        'april': '04', 'may': '05', 'june': '06',
        'july': '07', 'august': '08', 'september': '09',
        'october': '10', 'november': '11', 'december': '12'
    }
    current_year = datetime.now().year
    # Удаляем суффиксы -th, -st, -nd, -rd
    date_str = re.sub(r'(\d+)(st|nd|rd|th)\b', r'\1', date_str)
    
    # Разделяем день и месяц
    try:
        day, month = date_str.strip().split()
        day = day.zfill(2)  # Добавляем ведущий ноль если нужно
        month = months[month.lower()]
        return f"{day}.{month}.{current_year}"
    except Exception as e:
        print(f"Ошибка при парсинге даты {date_str}: {e}")
        return None

# =============================
# 1. Парсер КП (Китай/Корея/Вьетнам) (TransContainer.xlsx)
# =============================
def parse_TransContainer(file_path: str):
    xl = pd.ExcelFile(file_path)
    results = []
    company = "ТрансКонтейнер"
    def normalize_container(header_text: str) -> str:
        text = str(header_text).lower()
        if "40" in text and ("hc" in text or "hq" in text or "40ф" in text):
            return "40HC"
        if ("20" in text and "28" in text) or ("20ф" in text and "28" in text):
            return "20DC_28"
        if "20" in text or "20ф" in text:
            return "20DC"
        return None

    def normalize_port(cell_text: str) -> str:
        # Берем английское название в скобках, если есть
        text = str(cell_text)
        if "(" in text and ")" in text:
            inside = text[text.find("(") + 1:text.find(")")].strip()
            if inside:
                return inside
        return text.strip()

    for sheet_name in xl.sheet_names:
        df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)

        header_ports_row_idx = None
        header_container_row_idx = None
        sea_rate_row_idx = None

        # Поиск ключевых строк по сигнатурам
        for i in range(min(len(df), 200)):
            row_vals = df.iloc[i].astype(str).tolist()
            row_join = " ".join([v for v in row_vals if v and v != "nan"]).lower()
            if header_ports_row_idx is None and ("shanghai" in row_join or "шанхай" in row_join):
                header_ports_row_idx = i
                # контейнеры обычно в одной из следующих 1-5 строк
                for k in range(1, 6):
                    r = i + k
                    if r >= len(df):
                        break
                    probe = df.iloc[r].astype(str).str.lower().tolist()
                    score = sum(1 for v in probe if ("20" in v or "40" in v or "20ф" in v))
                    if score >= 3:
                        header_container_row_idx = r
                        break
                continue
            if sea_rate_row_idx is None and ("ставка до границы рф" in row_join or "ставка до границы" in row_join):
                sea_rate_row_idx = i
                continue

        # Если не нашли нужные строки — пропускаем лист
        if header_ports_row_idx is None or header_container_row_idx is None or sea_rate_row_idx is None:
            continue

        # Построим карту: column_index -> {port, container}
        col_to_port = {}
        col_to_container = {}

        ports_row = df.iloc[header_ports_row_idx].tolist()
        containers_row = df.iloc[header_container_row_idx].tolist()
        for col_idx in range(len(ports_row)):
            port_cell = ports_row[col_idx]
            cont_cell = containers_row[col_idx] if col_idx < len(containers_row) else None
            if str(port_cell) != "nan":
                col_to_port[col_idx] = normalize_port(port_cell)
                col_to_port[col_idx+1] = normalize_port(port_cell)
                col_to_port[col_idx+2] = normalize_port(port_cell)
            if str(cont_cell) != "nan":
                cont_norm = normalize_container(cont_cell)
                if cont_norm:
                    col_to_container[col_idx] = cont_norm
        # Морской фрахт: строка sea_rate_row_idx содержит ставку для каждой колонки контейнера
        sea_row = df.iloc[sea_rate_row_idx].tolist()
        for col_idx, value in enumerate(sea_row):
            if col_idx not in col_to_port or col_idx not in col_to_container:
                continue
            if pd.isna(value):
                continue
            # допускаем числа как int/float
            try:
                tariff = float(value)
            except Exception:
                continue
            size = "24" if col_to_container[col_idx] == "20DC" else ("28" if col_to_container[col_idx] == "20DC_28" else "30")
            pol = col_to_port[col_idx] + "/"
            for pol_item in pol.split("/"):
                if pol_item:
                    pol_port = port_dict.get(pol_item, pol_item)
                    pod_port = port_dict.get("ВМКТ", "ВМКТ")
                    results.append({
                        "transport_type": "sea",
                        "start_point": f"{pol_port}, {get_country(pol_port)}",
                        "end_point": f"{pod_port}, {get_country(pod_port)}",
                        "final_destination": "All, Россия",
                        "container_type": "20DC" if col_to_container[col_idx] == "20DC" or col_to_container[col_idx] == "20DC_28" else "40HC",
                        "weight_limit": size,
                        "cost": tariff,
                        "currency": currency_dict.get("$","$"),
                        "conditions": "FI-LO COC",
                        "departure_dates": "",
                        "customs": "",
                        "company": company
                    })
        # ЖД блоки: строки, начинающиеся с "НАЗНАЧЕНИЕМ НА СТАНЦИЮ" и колонка 1 = "Ставка жд перевозки"
        pattern = re.compile(r"НАЗНАЧЕНИЕМ НА СТАНЦИЮ\s+([А-ЯЁA-Z0-9\- ]+?)(?:\s+в составе КП|\s*\(|$).*?\(входная станция\s+([А-ЯЁа-яёA-Za-z0-9\- ]+)")
        for i in range(sea_rate_row_idx + 1, len(df)):
            row = df.iloc[i].tolist()
            first_cell = str(row[0]) if len(row) > 0 else "nan"
            second_cell = str(row[1]) if len(row) > 1 else "nan"
            
            if first_cell.startswith("НАЗНАЧЕНИЕМ НА СТАНЦИЮ") and "Ставка жд перевозки" in second_cell:
                # Выделим станцию назначения и входную станцию (если указана в скобках)
                match = pattern.search(first_cell)
                destination_station = None
                entrance = None
                if match:
                    station_to, station_from = match.groups()
                    destination_station = station_to.title().strip()
                    entrance = station_from.title().strip()
                
                # Тарифы по колонкам, выравниваем по контейнеру из col_to_container
                for col_idx in range(2, len(row)):
                    if col_idx not in col_to_container:
                        continue
                    value = row[col_idx]
                    if pd.isna(value):
                        continue
                    try:
                        tariff = float(value)
                    except Exception:
                        continue
                    pol_port = port_dict.get("ВМКТ", "ВМКТ")
                    city_station_to = get_city_station(destination_station)
                    city_station_from = get_city_station(entrance)
                    results.append({
                        "transport_type": "rail",
                        "start_point": f"{pol_port}, {get_country(pol_port)}",
                        "end_point": f"{city_station_to}, {get_country(city_station_to)}",
                        "final_destination": "All, Россия",#f"{city_station_to}, {get_country(city_station_to)}",
                        "container_type": "20DC" if col_to_container[col_idx] == "20DC" or col_to_container[col_idx] == "20DC_28" else "40HC",
                        "weight_limit": "24" if col_to_container[col_idx] == "20DC" else ("28" if col_to_container[col_idx] == "20DC_28" else "30"),
                        "cost": tariff,
                        "currency": currency_dict.get("руб","руб"),
                        "departure_dates": "",
                        "conditions": "",
                        "customs": f"Входящая станция {entrance}.\nСтанции назначения: {destination_station}.",
                        "company": company
                    })
    return pd.DataFrame(results)

# =============================
# 2.1 Парсер Тариф (RusTrans.xlsx)
# =============================
def parse_RusTrans(file_path: str):
    df = pd.read_excel(file_path, header=None)
    result = []
    type_route = None
    pol_rail = None
    drop_off_list = []
    company = "РусТранс Групп"
    for id_row in range(len(df)):
        row = df.iloc[id_row].astype(str).tolist()
        if "Ставки Ж/Д" in row[1]:
            conditions_rail = row[1]
    # Найти блоки "Морской фрахт" и "ЖД"
    for id_row in range(len(df)):
        row = df.iloc[id_row].astype(str).tolist()
        #print(row)
        if str(row[1]) == "Морской фрахт":
            type_route = "sea"
            continue
        
        if "ВМРП" in str(row[1]) and "ЖД" in str(row[1]):
            type_route = "rail"
            pol_rail = "ВМРП"
            continue

        if "Врангель" in str(row[1]) and "ЖД" in str(row[1]):
            type_route = "rail"
            pol_rail = "Врангель"
            continue
        
        if type_route == "sea" and "drop" in row[3]:
            for id_sea_row in range(3,12):
                if "drop" in row[id_sea_row]:
                    sp = row[id_sea_row].split("drop")
                    if sp[0].split()[0] == "20DC":
                        if '\\' in sp[1]:
                            for drop_off in sp[1].split('\\'):
                                drop_off_list.append(
                                    {"type_container": "20DC", "weight_limit": container_size_dict.get("20DC","24"), "destination": drop_off.strip(), "SOC/COC": "COC", "id_row":id_sea_row}
                                )
                        else:
                            for drop_off in sp[1].split('/'):
                                drop_off_list.append(
                                    {"type_container": "20DC", "weight_limit": container_size_dict.get("20DC","24"), "destination": drop_off.strip(), "SOC/COC": "COC", "id_row":id_sea_row}
                                )
                    elif sp[0].split()[0] == "40HC":
                        if '\\' in sp[1]:
                            for drop_off in sp[1].split('\\'):
                                drop_off_list.append(
                                    {"type_container": "40HC", "weight_limit": container_size_dict.get("40HC",""), "destination": drop_off.strip(), "SOC/COC": "COC", "id_row":id_sea_row}
                                )
                        else:
                            for drop_off in sp[1].split('/'):
                                drop_off_list.append(
                                    {"type_container": "40HC", "weight_limit": container_size_dict.get("40HC",""), "destination": drop_off.strip(), "SOC/COC": "COC", "id_row":id_sea_row}
                                )
                elif "COC" in row[id_sea_row]:
                    sp = row[id_sea_row].split()
                    drop_off_list.append(
                            {"type_container": "20DC", "weight_limit": container_size_dict.get("20DC","24"), "destination": sp[4], "SOC/COC": "COC", "id_row":id_sea_row}
                        )
                elif "SOC" in row[id_sea_row]:
                    sp = row[id_sea_row].split()
                    drop_off_list.append(
                            {"type_container": sp[0], "weight_limit": container_size_dict.get(sp[0],""), "destination": "All", "SOC/COC": "SOC", "id_row":id_sea_row}
                        )
                
            #print(drop_off_list)

        if type_route == "sea" and " - " in str(row[1]): #Только для "Морской фрахт"
            route = row[1]
            pol = route.split(" - ")[0]
            pod = route.split(" - ")[1] + "/"
            for drop_off in drop_off_list:
                end_point_region = region_dict.get(drop_off['destination'], drop_off['destination'])
                pol_port = port_dict.get(pol, pol)
                cost = row[drop_off['id_row']].replace("$",'')
                for pod_item in pod.split("/"):
                    if pod_item:
                        pod_ = port_dict.get(pod_item, pod_item)
                        cost_ = cost if "/" not in cost else cost.split("/")[0] if end_point_region == "Владивосток" and end_point_region == pod_ else cost.split("/")[1] if end_point_region == pod_ else ''
                        if cost_:
                            result.append({
                                "transport_type": type_route,
                                "start_point": f"{pol_port}, {get_country(pol_port)}", #Порт погрузки
                                "end_point": f"{pod_}, {get_country(pod_)}", #Порт выгрузки
                                "final_destination": f"{end_point_region}, {get_country(end_point_region)}",
                                "container_type": drop_off['type_container'],
                                "weight_limit": drop_off['weight_limit'] if "weight_limit" in drop_off else None,
                                "cost": cost_,
                                "currency": currency_dict.get("$","$"),
                                "departure_dates": "",
                                "conditions": f"FI-LO {drop_off['SOC/COC']}",
                                "company": company,
                                "customs": ""
                            })
                '''if "/" in pod:
                    for pod_item in pod.split("/"):
                        result.append({
                            "transport_type": type_route,
                            "pol": f"{pol_port}, {get_country(pol_port)}", #Порт погрузки
                            "pod": f"{port_dict.get(pod_item, pod_item)}, {get_country(port_dict.get(pod_item, pod_item))}", #Порт выгрузки
                            "end_point": f"{end_point_region}, {get_country(end_point_region)}",
                            "container_type": drop_off['type_container'],
                            "weight_limit": drop_off['weight_limit'] if "weight_limit" in drop_off else None,
                            "cost": cost if "/" not in cost else cost.split("/")[0] if ,
                            "currency": "$",
                            "conditions": f"FI-LO {drop_off['SOC/COC']}"
                        })
                else:
                    result.append({
                        "transport_type": type_route,
                        "pol": f"{pol_port}, {get_country(pol_port)}", #Порт погрузки
                        "pod": f"{port_dict.get(pod, pod)}, {get_country(port_dict.get(pod, pod))}", #Порт выгрузки
                        "end_point": f"{end_point_region}, {get_country(end_point_region)}",
                        "container_type": drop_off['type_container'],
                        "weight_limit": drop_off['weight_limit'] if "weight_limit" in drop_off else None,
                        "cost": row[drop_off['id_row']],
                        "currency": "$",
                        "conditions": f"FI-LO {drop_off['SOC/COC']}"
                    })'''

        if "руб" in row[9] and type_route == "rail":
            security_20 = row[9].split("руб")[0].split("/")[0].strip().replace(" ","")
            security_40 = row[9].split("руб")[0].split("/")[1].strip().replace(" ","")
            pol_r = port_dict.get(pol_rail, pol_rail)
            for id_rail_row in range(6,9):
                result.append({
                    "transport_type": type_route,
                    "start_point": f"{pol_r}, {get_country(pol_r)}",
                    "end_point": f"{row[1]}, {get_country(row[1])}",
                    "final_destination": "All, Россия",#f"{row[1]}, {get_country(row[1])}", #region_dict.get(row[1], row[1]),
                    #"Destination_station": row[2].split(","), #d_station.strip(), #Станция назначения
                    "container_type": "20DC" if id_rail_row==6 or id_rail_row==7 else "40HC",
                    "weight_limit": "24" if id_rail_row==6 else "28",
                    "cost": row[id_rail_row],
                    "currency": currency_dict.get("руб","руб"),
                    "departure_dates": "",
                    "company": company,
                    "conditions": "",
                    "customs": (f"Охрана: {security_20}.\n{conditions_rail}" if id_rail_row==6 or id_rail_row==7 else f"Охрана: {security_40}.\n{conditions_rail}") + f"Станции назначения: {row[2]}"
                })
    #return result
    return pd.DataFrame(result)

# =============================
# 2.2 Парсер Тариф (RusTrans2.xlsx)
# =============================
def parse_RusTrans_all_tranc(file_path: str):
    df = pd.read_excel(file_path, header=None)
    result = []
    type_route = None
    pol = None
    drop_off_list = []
    company = "РусТранс Групп"
    # Найти блоки "Морской фрахт" и "ЖД"
    for i in range(len(df)):
        row = df.iloc[i].astype(str).tolist()
        #print(row)
        if str(row[1]) == "Морской фрахт":
            type_route = "Морской фрахт"
            continue
        
        if "ВМРП" in str(row[1]) and "ЖД" in str(row[1]):
            type_route = "ЖД ВМРП"
            pol = "ВМРП"
            continue

        if "Врангель" in str(row[1]) and "ЖД" in str(row[1]):
            type_route = "ЖД Врангель"
            pol = "Врангель"
            continue
        
        if type_route == "Морской фрахт" and "drop" in row[3]:
            for i in range(3,12):
                if "drop" in row[i]:
                    sp = row[i].split("drop")
                    if sp[0].split()[0] == "20DC":
                        if '\\' in sp[1]:
                            for drop_off in sp[1].split('\\'):
                                drop_off_list.append(
                                    {"type_container": "20DC", "size": container_size_dict.get("20DC","до 24т"), "destination": drop_off.strip(), "SOC/COC": "COC", "id_row":i}
                                )
                        else:
                            for drop_off in sp[1].split('/'):
                                drop_off_list.append(
                                    {"type_container": "20DC", "size": container_size_dict.get("20DC","до 24т"), "destination": drop_off.strip(), "SOC/COC": "COC", "id_row":i}
                                )
                    elif sp[0].split()[0] == "40HC":
                        if '\\' in sp[1]:
                            for drop_off in sp[1].split('\\'):
                                drop_off_list.append(
                                    {"type_container": "40HC", "size": container_size_dict.get("40HC",""), "destination": drop_off.strip(), "SOC/COC": "COC", "id_row":i}
                                )
                        else:
                            for drop_off in sp[1].split('/'):
                                drop_off_list.append(
                                    {"type_container": "40HC", "size": container_size_dict.get("40HC",""), "destination": drop_off.strip(), "SOC/COC": "COC", "id_row":i}
                                )
                elif "COC" in row[i]:
                    sp = row[i].split()
                    drop_off_list.append(
                            {"type_container": "20DC", "size": container_size_dict.get("20DC","до 24т"), "destination": sp[4], "SOC/COC": "COC", "id_row":i}
                        )
                elif "SOC" in row[i]:
                    sp = row[i].split()
                    drop_off_list.append(
                            {"type_container": sp[0], "size": container_size_dict.get(sp[0],""), "destination": None, "SOC/COC": "SOC", "id_row":i}
                        )
                
            #print(drop_off_list)

        if type_route == "Морской фрахт" and " - " in str(row[1]): #Только для "Морской фрахт"
            route = row[1]
            pol = route.split(" - ")[0]
            pod = route.split(" - ")[1]
            for drop_off in drop_off_list:
                if "/" in pod:
                    for pod_item in pod.split("/"):
                        result.append({
                            "type_route": type_route,
                            "pol": pol, #Порт погрузки
                            "pod": pod_item, #Порт выгрузки
                            "destination": region_dict.get(drop_off['destination'], drop_off['destination']),
                            "container": drop_off['type_container'],
                            "size": drop_off['size'] if "size" in drop_off else None,
                            "tarif": row[drop_off['id_row']],
                            "security": None,
                            "currency": "$",
                            "SOC/COC": drop_off['SOC/COC']
                        }) 
                else:
                    result.append({
                        "type_route": type_route,
                        "pol": pol, #Порт погрузки
                        "pod": pod, #Порт выгрузки
                        "destination": region_dict.get(drop_off['destination'], drop_off['destination']),
                        "container": drop_off['type_container'],
                        "size": drop_off['size'] if "size" in drop_off else None,
                        "tarif": row[drop_off['id_row']],
                        "security": None,
                        "currency": "$",
                        "SOC/COC": drop_off['SOC/COC']
                    })

        if "руб" in row[9] and "ЖД" in type_route:
            for i in range(6,9):
                result.append({
                    "type_route": type_route,
                    "pol": pol,
                    "pod": row[1],
                    "destination": region_dict.get(row[1], row[1]),
                    #"Destination_station": row[2].split(","), #d_station.strip(), #Станция назначения
                    "container": "20DC" if i==6 or i==7 else "40HC",
                    "size": "до 24т" if i==6 else "до 28т",
                    "tarif": row[i],
                    "security": row[9].split("руб")[0],
                    "currency": "руб",
                    "SOC/COC": "COC"
                })
    #return result
    return pd.DataFrame(result)

# =============================
# 3. Парсер Тариф + Расписание (Marmed-container.xlsx) 
# =============================
def parse_MarmedContainer(file_path: str):
    xl = pd.ExcelFile(file_path)
    result = []
    company = "Мармед - Контейнерное Агенство"
    def parse_IMPORT_sheet_MarmedContainer(df, sheet_name):
        results = []

        # ищем строку с POL/POD
        header_row = None
        for i, row in df.iterrows():
            values = [str(cell).strip().upper() for cell in row if pd.notna(cell)]
            if "POL" in values and "POD" in values:
                header_row = i
                break
        if header_row is None:
            return results

        # следующая строка содержит контейнерные колонки
        container_row = header_row + 1
        headers = df.iloc[header_row].fillna("").astype(str).tolist()
        container_headers = df.iloc[container_row].fillna("").astype(str).tolist()

        # формируем карту колонок
        col_map = {}
        for idx, h in enumerate(headers):
            h_clean = h.strip()
            if h_clean:
                col_map[h_clean] = idx

        # добавляем контейнерные колонки
        for idx, h in enumerate(container_headers):
            if h.strip() in container_size_dict or h.strip().replace("`","") in container_size_dict:
                col_map[h.strip()] = idx

        tarif_filter = col_map["При оплате фрахта в рублях в РФ"]
        # идём по строкам после container_row
        for _, row in df.iloc[container_row+1:].iterrows():
            if pd.isna(row[col_map.get("POL", -1)]) or pd.isna(row[col_map.get("POD", -1)]):
                continue
            
            start_point_no_filter = str(row[col_map["POL"]]).strip()
            end_point_no_filter = str(row[col_map["POD"]]).strip()

            final_destination = str(row[col_map.get("Country", "")]).strip() if "Country" in col_map else ""
            conditions = str(row[col_map.get("TERMS", "")]).strip() if "TERMS" in col_map else ""
            SOC_COC = str(row[col_map.get("CNTR", "")]).strip()
            validity = str(row[col_map.get("Validity", "")]).strip()

            for key, idx in col_map.items():
                if key in container_size_dict or key.replace("`","") in container_size_dict:
                    tariff = row[idx] if idx >= tarif_filter else "None"
                    if pd.isna(tariff):
                        continue
                    container_type = key.replace("`","") if key.replace("`","") in container_size_dict else key
                    for start_p in start_point_no_filter.split("/"):
                        pol_port = port_dict.get(start_p.strip().title(), start_p.strip().title())
                        
                        for end_p in end_point_no_filter.split("/"):
                            pod_port = port_dict.get(end_p.strip().title(), end_p.strip().title())
                            for soc_coc in SOC_COC.split("/"):
                                results.append({
                                    "transport_type": "sea",
                                    "start_point": f"{pol_port}, {get_country(pol_port)}",
                                    "end_point": f"{pod_port}, {get_country(pod_port)}",
                                    "final_destination": f"All, {get_country(pod_port)}",
                                    "container_type": container_type,
                                    "weight_limit": container_size_dict[container_type],
                                    "cost": tariff,
                                    "currency": currency_dict.get("$", "$"),
                                    "departure_dates": "",
                                    "customs": f"Validity:{validity}",
                                    "conditions": f"{conditions} {soc_coc}",
                                    "company": company
                                })
        return results

    def parse_EXPORT_sheet_MarmedContainer(df, sheet_name):
        results = []

        # ищем строку с POL/POD
        header_row = None
        for i, row in df.iterrows():
            values = [str(cell).strip().upper() for cell in row if pd.notna(cell)]
            if "POL" in values and "POD" in values:
                header_row = i
                break
        if header_row is None:
            return results

        # следующая строка содержит контейнерные колонки
        container_row = header_row + 1
        headers = df.iloc[header_row].fillna("").astype(str).tolist()
        container_headers = df.iloc[container_row].fillna("").astype(str).tolist()

        # формируем карту колонок
        col_map = {}
        for idx, h in enumerate(headers):
            h_clean = h.strip()
            if h_clean:
                col_map[h_clean] = idx

        # добавляем контейнерные колонки
        for idx, h in enumerate(container_headers):
            if h.strip() in container_size_dict or h.strip().replace("`","") in container_size_dict:
                col_map[h.strip()] = idx

        tarif_filter = col_map["При оплате фрахта в рублях в РФ"]
        # идём по строкам после container_row
        for _, row in df.iloc[container_row+1:].iterrows():
            if pd.isna(row[col_map.get("POL", -1)]) or pd.isna(row[col_map.get("POD", -1)]):
                continue
            
            start_point_no_filter = str(row[col_map["POL"]]).strip()
            end_point_no_filter = str(row[col_map["POD"]]).strip()

            final_destination = str(row[col_map.get("Country", "")]).strip() if "Country" in col_map else ""
            conditions = str(row[col_map.get("TERMS", "")]).strip() if "TERMS" in col_map else ""

            validity = str(row[col_map.get("Validity", "")]).strip()

            PICKUP_FEE = str(row[col_map.get("PICKUP FEE", "")]).strip()

            SOC_COC = str(row[col_map.get("SOC/COC", "")]).strip()

            for key, idx in col_map.items():
                if key in container_size_dict or key.replace("`","") in container_size_dict:
                    tariff = row[idx] if idx >= tarif_filter else "None"
                    if pd.isna(tariff):
                        continue
                    container_type = key.replace("`","") if key.replace("`","") in container_size_dict else key
                    
                    

                    for start_p in start_point_no_filter.split("/"):
                        pol_port = port_dict.get(start_p.strip().title(), start_p.strip().title())
                        
                        for end_p in end_point_no_filter.split("/"):
                            pod_port = port_dict.get(end_p.strip().title(), end_p.strip().title())
                            
                            for soc_coc in SOC_COC.split("/"):
                                if "/" in PICKUP_FEE and "20" in container_type:
                                    PICKUP_FEE = PICKUP_FEE.split("/")[0].strip()
                                elif "/" in PICKUP_FEE and "40" in container_type:
                                    PICKUP_FEE = PICKUP_FEE.split("/")[1].strip()
                                results.append({
                                    "transport_type": "sea",
                                    "start_point": f"{pol_port}, {get_country(pol_port)}",
                                    "end_point": f"{pod_port}, {get_country(pod_port)}",
                                    "final_destination": f"All, {get_country(pod_port)}",
                                    "container_type": container_type,
                                    "weight_limit": container_size_dict[container_type],
                                    "cost": tariff,
                                    "currency": currency_dict.get("$", "$"),
                                    "company": company,
                                    "customs": f"Validity:{validity}, PICKUP_FEE:{PICKUP_FEE}",
                                    "conditions": f"{conditions} {soc_coc}"
                                })
        return results

    for sheet in xl.sheet_names:
        df = pd.read_excel(file_path, sheet_name=sheet, header=None)
        
        if "IMPORT" in sheet:
            result.extend(parse_IMPORT_sheet_MarmedContainer(df, sheet))
        elif "EXPORT" in sheet:
            result.extend(parse_EXPORT_sheet_MarmedContainer(df, sheet))
    
    return pd.DataFrame(result)

# =============================
# 4. Парсер HS_CHINA_LIMITED.xlsx
# =============================
def parse_HS_CHINA_LIMITED(file_path: str):
    df = pd.read_excel(file_path, header=None)
    result = []
    #print(df.columns.tolist())
    # Ищем строку с заголовками (обычно строка 1)
    
    header_row = None
    for i in range(min(10, len(df))):
        row = df.iloc[i].astype(str).str.strip().tolist()
        if 'POD' in row and ('POL' in row or 'POL(FOB)' in row) and 'RATE' in row:
            header_row = i
            break
    
    if header_row is None:
        print("Не найдена строка с заголовками")
        return pd.DataFrame()
    
    # Обрабатываем данные начиная со строки после заголовков
    current_region = None
    current_pol = None
    current_rate = None
    current_validity = None
    current_route = None
    current_remark = None
    
    for i in range(header_row + 1, len(df)):
        row = df.iloc[i].astype(str).tolist()
        # Пропускаем пустые строки
        if all(pd.isna(cell) or str(cell).strip() == 'nan' for cell in row):
            continue
        
        # Определяем тип данных в строке
        if row[0] and str(row[0]).strip() not in ['nan', '']:
            # Это регион (USWC, USEC, USGC, CANADA)
            current_region = str(row[0]).strip()
            current_pol = str(row[2]).strip() if len(row) > 2 and str(row[2]).strip() not in ['nan', ''] else None
            current_rate = str(row[3]).strip() if len(row) > 3 and str(row[3]).strip() not in ['nan', ''] else None
            current_validity = str(row[4]).strip() if len(row) > 4 and str(row[4]).strip() not in ['nan', ''] else None
            current_route = str(row[5]).strip() if len(row) > 5 and str(row[5]).strip() not in ['nan', ''] else None
            current_remark = str(row[6]).strip() if len(row) > 6 and str(row[6]).strip() not in ['nan', ''] else None
            # Если есть порт в колонке 1, добавляем запись
            if row[1] and str(row[1]).strip() not in ['nan', '']:
                pod = str(row[1]).strip()
                if "/" in pod:
                    for pod_item in pod.split("/"):
                        add_tariff_entry_HS_CHINA_LIMITED(result, current_region, pod_item, current_pol, current_rate, 
                               current_validity, current_route, current_remark)
                else:
                    add_tariff_entry_HS_CHINA_LIMITED(result, current_region, pod, current_pol, current_rate, 
                               current_validity, current_route, current_remark)
        
        elif row[1] and str(row[1]).strip() not in ['nan', '']:
            # Это порт назначения в колонке 1
            pod = str(row[1]).strip()
            
            # Проверяем, есть ли тариф в этой строке
            rate_in_row = str(row[3]).strip() if len(row) > 3 and str(row[3]).strip() not in ['nan', ''] else None
            
            add_tariff_entry_HS_CHINA_LIMITED(result, current_region, pod, current_pol, 
                           rate_in_row or current_rate, current_validity, current_route, current_remark)
    
    return pd.DataFrame(result)

def add_tariff_entry_HS_CHINA_LIMITED(result, region, pod, pol, rate, validity, route, remark):
    """Добавляет записи тарифов в результат"""
    if not pod or not rate:
        return
    company = "HS CHINA LIMITED"
    # Разбираем тариф (формат "1700/2000" или "3800/4300")
    rates = str(rate).split('/')
    
    # Определяем типы контейнеров
    container_types = []
    if len(rates) >= 2:
        container_types = ['20DC', '40HC']
    elif len(rates) == 1:
        container_types = ['20DC']  # По умолчанию
    
    # Разбираем POL (порт отправления)
    pol_ports = []
    if pol and '/' in str(pol):
        pol_ports = [p.strip() for p in str(pol).split('/')]
    elif pol:
        pol_ports = [str(pol).strip()]
    
    # Разбираем REMARK (SOC/COC)
    soc_coc_options = []  # По умолчанию
    if remark and '/' in str(remark):
        soc_coc_options = [r.strip() for r in str(remark).split('/')]
    elif remark:
        soc_coc_options.append(str(remark).strip())
    
    # Создаем записи для каждого порта отправления и типа контейнера
    for pol_port in pol_ports:
        for i, container_type in enumerate(container_types):
            if i < len(rates):
                tariff_value = rates[i]
                pol_r = port_dict.get(pol_port, pol_port)
                pod_r = port_dict.get(pod, pod)
                for soc_coc in soc_coc_options:
                    result.append({
                        "transport_type": "sea",
                        "start_point": f"{pol_r}, {get_country(pol_r)}",  # Порт отправления
                        "end_point": f"{pod_r}, {region_dict.get(region,region)}",      # Порт назначения
                        "final_destination": f"All, {region_dict.get(region,region)}",
                        "container_type": container_type,
                        "weight_limit": container_size_dict.get(container_type,""),
                        "cost": tariff_value,
                        "currency": currency_dict.get("$","$"),
                        "departure_dates": "",
                        "company": company,
                        "customs": f"Route:{route}, Validity:{validity}",
                        "conditions": f"{soc_coc}"
                    })

# =============================
# 5. Парсер Torgmoll.xlsx
# =============================
def parse_Torgmoll(file_path: str):
    xl = pd.ExcelFile(file_path)
    result = []
    company = "Torgmoll"
    for sheet in xl.sheet_names:
        df = pd.read_excel(file_path, sheet_name=sheet, header=None)
        
        if "КНР-СПБ" in sheet and "BUSAN" not in sheet:
            result.extend(parse_CNR_SPB_sheet_Torgmoll(df, sheet))
        '''elif "BUSAN" in sheet:
            result.extend(parse_YUVA_sheet_Torgmoll(df, sheet))'''
        '''elif sheet == "Detention":
            result.extend(parse_Detention_sheet_Torgmoll(df, sheet))'''
    
    return pd.DataFrame(result)

def parse_CNR_SPB_sheet_Torgmoll(df, sheet_name):
    """Парсит лист КНР-СПБ"""
    result = []
    company = "Torgmoll"
    # Ищем строку с заголовками (строка 2)
    header_row = 2
    charges_peter = False
    charges_peter_i = 0
    charges_kalin = False
    charges_kalin_i = 0
    # Обрабатываем данные начиная со строки 3
    for i in range(3, len(df)):
        row = df.iloc[i].astype(str).tolist()
        
        # Пропускаем пустые строки
        if all(pd.isna(cell) or str(cell).strip() == 'nan' for cell in row):
            continue
        if "St. Petersburg Import Charges" in str(row[0]):
            charges_peter = True
            continue
        if "KALININGRAD Import Charges" in str(row[0]):
            charges_kalin = True
            charges_peter_i = 0
            charges_peter = False
            continue
        # Ищем строки с портами и тарифами
        if (not charges_peter and not charges_kalin) and row[0] and str(row[0]).strip() not in ['nan', '']:
            pol = str(row[0]).strip()
            pod_list = str(row[1]).strip().split("(")
            pod = pod_list[0].strip()
            # Проверяем, есть ли тарифы в строке
            for col_idx in range(1, len(row)):
                if row[col_idx] and str(row[col_idx]).strip() not in ['nan', '']:
                    tariff = str(row[col_idx]).strip() if row[col_idx] != "/" and row[col_idx] != "—" else None
                    
                    # Определяем тип контейнера по заголовку колонки
                    container_type = get_container_type_from_header(df.iloc[header_row, col_idx])
                    
                    if container_type and tariff:
                        if "/" in pol:
                            for pol_item in pol.split("/"):
                                pol_item = pol_item.strip()
                                pol_port = port_dict.get(pol_item, pol_item)
                                result.append({
                                    "transport_type": "sea",
                                    "start_point": f"{pol_port}, {get_country(pol_port)}",
                                    "end_point": f"{pod}, Россия",
                                    "final_destination": "All, Россия",
                                    "container_type": container_type,
                                    "weight_limit": container_size_dict.get(container_type,""),
                                    "cost": tariff,
                                    "currency": currency_dict.get("$","$"),
                                    "departure_dates": "",
                                    "company": company,
                                    "customs": f"{pod_list[1].replace(')','')}",
                                    "conditions": ("FI-FO COC." if "COC" in str(df.iloc[header_row, col_idx]) else "FI-FO SOC.")
                                })
                        else:
                            pol_port = port_dict.get(pol, pol)
                            result.append({
                                "transport_type": "sea",
                                "start_point": f"{pol_port}, {get_country(pol_port)}",
                                "end_point": f"{pod}, Россия",
                                "final_destination": "All, Россия",
                                "container_type": container_type,
                                "weight_limit": container_size_dict.get(container_type,""),
                                "cost": tariff,
                                "currency": currency_dict.get("$","$"),
                                "departure_dates": "",
                                "company": company,
                                "customs": f"{pod_list[1].replace(')','')}",
                                "conditions": ("FI-FO COC." if "COC" in str(df.iloc[header_row, col_idx]) else "FI-FO SOC.")
                            })

        if charges_peter and "CHARGE" in str(row[0]):
            charges_peter_i = i
            continue
        
        if charges_kalin and "CHARGE" in str(row[0]):
            charges_kalin_i = i
            continue
        
        if charges_peter_i != 0 or charges_kalin_i !=0:
            for col_idx in range(2, len(row)):
                if row[col_idx] and str(row[col_idx]).strip() not in ['nan', '']:
                    container_types = get_container_type_from_header(df.iloc[charges_peter_i if charges_peter_i !=0 else charges_kalin_i, col_idx]).replace(" ","") + "/"
                    for container_type in container_types.split("/"):
                        for res in result:
                            if res["container_type"] == container_type:
                                if "Калининград" in res["end_point"] and charges_kalin_i !=0:
                                    res["conditions"] += f"\n{str(row[0]).strip()}: {str(row[col_idx]).strip()}."
                                elif "Санкт-Петербург" in res["end_point"] and charges_peter_i !=0:
                                    res["conditions"] += f"\n{str(row[0]).strip()}: {str(row[col_idx]).strip()}."
        
        if "Примечание" in str(row[0]):
            charges_kalin = False 
            charges_kalin_i = 0
            for res in result:
                res["conditions"] += f"\n{str(row[0])}"


    return result

def parse_YUVA_sheet_Torgmoll(df, sheet_name):
    """Парсит лист ЮВА (+BUSAN) - КНР - СПБ"""
    result = []
    
    # Ищем строку с заголовками (строка 1)
    header_row = 1
    
    # Обрабатываем данные начиная со строки 3
    for i in range(3, len(df)):
        row = df.iloc[i].astype(str).tolist()
        #print(row)
        # Пропускаем пустые строки
        if all(pd.isna(cell) or str(cell).strip() == 'nan' for cell in row):
            continue
        
        # Ищем строки с портами и тарифами
        if row[0] and str(row[0]).strip() not in ['nan', '']:
            pol = str(row[0]).strip()
            transshipment = str(row[1]).strip() if len(row) > 1 and str(row[1]).strip() not in ['nan', ''] else None
            
            # Проверяем тарифы для 20GP и 40HC
            if len(row) > 2 and row[2] and str(row[2]).strip() not in ['nan', '']:
                tariff_20gp = str(row[2]).strip() if row[2] != "/" and row[2] != "—" else None
                if tariff_20gp:
                    result.append({
                        "transport_type": "sea",
                        "start_point": pol.title(),
                        "end_point": "Санкт-Петербург",
                        "final_destination": "All, Россия",
                        "container_type": "20GP",
                        "weight_limit": container_size_dict.get("20GP",""),
                        "cost": tariff_20gp,
                        "currency": currency_dict.get("$","$"),
                        "conditions": "COC"
                    })
            
            if len(row) > 3 and row[3] and str(row[3]).strip() not in ['nan', '']:
                tariff_40hc = str(row[3]).strip() if row[3] != "/" and row[3] != "—" else None
                if tariff_40hc:
                    result.append({
                        "transport_type": "sea",
                        "start_point": pol,
                        "end_point": "Санкт-Петербург", 
                        "final_destination": "All, Россия",
                        "container_type": "40HC",
                        "weight_limit": container_size_dict.get("40HC",""),
                        "cost": tariff_40hc,
                        "currency": currency_dict.get("$","$"),
                        "conditions": "COC"
                    })
    
    return result

def parse_Detention_sheet_Torgmoll(df, sheet_name):
    """Парсит лист Detention"""
    result = []
    
    # Этот лист содержит информацию о демередже и детеншене
    # Обычно это не тарифы на перевозку, а дополнительные сборы
    # Поэтому возвращаем пустой список или можно добавить специальную обработку
    
    return result

def get_container_type_from_header(header_cell):
    """Определяет тип контейнера из заголовка колонки"""
    header = str(header_cell).lower()
    
    if '20gp' in header or '20 gp' in header:
        return '20GP'
    elif '40hc' in header or '40 hc' in header:
        return '40HC'
    elif '20rf' in header or '20 rf' in header:
        return '20RF'
    elif '40rf' in header or '40 rf' in header:
        return '40RF'
    elif '20tank' in header or '20 tank' in header:
        return '20TK'
    elif len(header.split()) == 1:
        return header.upper()
    else:
        return None

# =============================
# 6. Парсер Mohill.xlsx
# =============================
def parse_Mohill(file_path: str):
    """
    Парсит Mohill.xlsx (листы: 'SPB ', 'NOVO', 'VVO+Railway') в унифицированный DataFrame.

    Выходные столбцы:
      - type_route         — тип маршрута ("Морской фрахт" / "ЖД")
      - pol                — порт/город отправления
      - pod                — порт/город выгрузки
      - transshipment      — (не используется здесь, оставляем None)
      - destination        — конечный пункт (для моря = POD/терминал; для ЖД = FOR)
      - container          — тип контейнера ("20GP" / "40HQ")
      - type_container     — дублирует container (для совместимости)
      - size               — "до 24т" для 20GP, "до 28т" для 40HQ
      - tarif              — ставка (число)
      - currency           — "$" или "руб"
      - security           — "ВОХР" при наличии в Remarks (иначе None)
      - SOC/COC / own      — "COC"
      - carrier            — перевозчик/оператор из столбца Carrier
      - sheet              — имя листа (для трассировки)
    """
    xl = pd.ExcelFile(file_path)
    rows = []
    company = "Mohill Rus"
    def _clean_num(val):
        if pd.isna(val):
            return None
        if isinstance(val, (int, float, np.integer, np.floating)):
            return float(val)
        s = str(val)
        m = re.search(r'(\d+(?:[.,]\d+)?)', s.replace(' ', ''))
        return float(m.group(1).replace(',', '.')) if m else None

    def _contains_vohr(text: str) -> bool:
        if not text:
            return False
        t = str(text).upper()
        return ("ВОХР" in t) or ("VOHR" in t)

    def _extract_usd_rub(text):
        """Разбирает строку вида '1200USD + 215000RUB' -> (1200.0, 215000.0)."""
        if text is None or (isinstance(text, float) and np.isnan(text)):
            return (None, None)
        t = str(text).upper().replace(' ', '')
        m_usd = re.search(r'(\d+(?:[.,]\d+)?)USD', t)
        m_rub = re.search(r'(\d+(?:[.,]\d+)?)RUB', t)
        usd = float(m_usd.group(1).replace(',', '.')) if m_usd else None
        rub = float(m_rub.group(1).replace(',', '.')) if m_rub else None
        return usd, rub

    for sheet in xl.sheet_names:
        df = pd.read_excel(file_path, sheet_name=sheet)

        # Листы СПб/Новороссийск: первая строка — легенда размеров ("20GP", "40HQ")
        if sheet.strip() in ("SPB", "NOVO"):
            if len(df) == 0:
                continue
            df = df.iloc[1:].reset_index(drop=True)  # пропускаем строку-легенду
            if 'Carrier' in df.columns:
                df['Carrier'] = df['Carrier'].ffill()
            for _, row in df.iterrows():
                pol_raw = str(row.get('POL') or '').strip()
                pod = str(row.get('POD') or '').strip()
                if not pol_raw:
                    continue
                carrier = (str(row.get('Carrier') or '').strip()) or None
                remarks = (str(row.get('Remarks') or '').strip()) or None
                route = (str(row.get('Route') or '').strip()) or None
                time = (str(row.get('V/V ETD') or '').strip()) or None
                security = "ВОХР" if _contains_vohr(remarks) else None

                t20 = _clean_num(row.get('COC'))          # 20GP
                t40 = _clean_num(row.get('Unnamed: 4'))   # 40HQ

                # Если POL содержит несколько портов — делим
                pol_list = [p.strip() for p in pol_raw.split('/') if p and p.strip()]

                for pol in pol_list:
                    pol_port = port_dict.get(pol, pol)
                    pod_port = port_dict.get(pod.split()[0] if "SPB" in pod or "NOVO" in pod else pod, pod)
                    if t20 is not None:
                        rows.append({
                            "transport_type": "sea",
                            "start_point": f"{pol_port}, {get_country(pol_port)}",
                            "end_point": f"{pod_port}, {get_country(pod_port)}",
                            "final_destination": f"All, {get_country(pod_port)}",
                            "container_type": "20GP",
                            "weight_limit": "24",
                            "cost": t20,
                            "currency": currency_dict.get("$","$"),
                            "departure_dates": convert_date(f"{time.split()[0]} {time.split()[1]}") if (len(time.split()) != 3 and len(time.split()) != 1) else "" ,
                            "carrier_name": carrier or "",
                            "company": company,
                            "customs": f"Route:{route}, Remarks:{remarks}, POD:{pod}",
                            "conditions": "COC"
                        })
                    if t40 is not None:
                        rows.append({
                            "transport_type": "sea",
                            "start_point": f"{pol_port}, {get_country(pol_port)}",
                            "end_point": f"{pod_port}, {get_country(pod_port)}",
                            "final_destination": f"All, {get_country(pod_port)}",
                            "container_type": "40HQ",
                            "weight_limit": "28",
                            "cost": t40,
                            "currency": currency_dict.get("$","$"),
                            "departure_dates": convert_date((f"{time.split()[0]} {time.split()[1]}")) if (len(time.split()) != 3 and len(time.split()) != 1) else "" ,
                            "carrier_name": carrier or "",
                            "company": company,
                            "customs": f"Route:{route}, Remarks:{remarks}, POD:{pod}",
                            "conditions": "COC"
                        })

        # Лист Владивосток + ЖД (делим на 2 плеча)
        elif sheet.strip() == "VVO+Railway":
            break
            if len(df) == 0:
                continue
            df = df.iloc[1:].reset_index(drop=True)  # аналогично: часто есть служебная строка
            if 'Carrier' in df.columns:
                df['Carrier'] = df['Carrier'].ffill()

            for _, row in df.iterrows():
                fob_raw = str(row.get('FOB') or '').strip()
                if not fob_raw:
                    continue
                cy = (str(row.get('CY') or '').strip()) or None
                for_dest = (str(row.get('FOR') or '').strip()) or None
                carrier = (str(row.get('Carrier') or '').strip()) or None
                remarks = (str(row.get('Remarks') or '').strip()) or None
                validity = (str(row.get('Validity') or '').strip()) or None
                time = (str(row.get('V/V ETD') or '').strip()) or None
                security = "ВОХР" if _contains_vohr(remarks) else None
                usd, rub = _extract_usd_rub(row.get('COC'))

                # Плечо 1: море до Владивостока (40HQ)
                if usd is not None:
                    for pol in [p.strip() for p in fob_raw.split('/') if p and p.strip()]:
                        pol_port = port_dict.get(pol, pol)
                        rows.append({
                            "transport_type": "sea",
                            "start_point": f"{pol_port}, {get_country(pol_port)}",
                            "end_point": "Владивосток, Россия",
                            "final_destination": cy or "Владивосток",
                            "container_type": "40HQ",
                            "weight_limit": "28",
                            "cost": usd,
                            "currency": currency_dict.get("$","$"),
                            "departure_dates": time,
                            "carrier_name": carrier or "",
                            "company": company,
                            "customs": f"Validity:{validity}, Remarks:{remarks}",
                            "conditions": "COC"
                        })

                # Плечо 2: ЖД Владивосток → FOR (40HQ)
                if rub is not None and for_dest:
                    pod_port = port_dict.get(for_dest, for_dest)
                    rows.append({
                        "transport_type": "rail",
                        "start_point": "Владивосток, Россия",
                        "end_point": f"{pod_port}, {get_country(region.get(pod_port,pod_port))}",
                        "final_destination": f"All, {get_country(region.get(pod_port,pod_port))}",
                        "container_type": "40HQ",
                        "weight_limit": "28",
                        "cost": rub,
                        "currency": currency_dict.get("руб","руб"),
                        "departure_dates": time,
                        "carrier_name": carrier or "",
                        "company": company,
                        "customs": f"Validity:{validity}, Remarks:{remarks}",
                        "conditions": "COC"
                    })

        # Если появятся новые листы — аккуратно игнорируем или можно добавить сюда ветку парсинга

    df_out = pd.DataFrame(rows)

    # приведение типов/пробелов
    if not df_out.empty:
        df_out["start_point"] = df_out["start_point"].str.strip()
        df_out["end_point"] = df_out["end_point"].str.strip()
        df_out["final_destination"] = df_out["final_destination"].astype(str).str.strip()
        # сортировка для стабильности
        '''df_out = df_out[
            ["transport_type","start_point","end_point","final_destination",
             "container_type","weight_limit","cost","currency",
             "conditions"]
        ]'''
    return df_out

# =============================
# 7. Парсер EuroSib
# =============================
def parse_tariff_matrix_to_json(df: str, output_json: str = None):
    """
    Парсит таблицы вида:
    - Колонка 0: Пункт отправления (origin), может быть заполнена только в первой строке группы
    - Колонка 1: Станция назначения (destination)
    - Далее несколько колонок тарифов с многострочными заголовками (например: 20’DC (<24т брутто груза), (>24т брутто груза), 40'HC (<28т брутто груза))

    Возвращает список маршрутов с ценами:
    [
        {
            "origin": str,
            "destination": str,
            "prices": { normalized_header: int|None, ... },
            "raw_headers": { normalized_header: original_header_text, ... }
        }
    ]
    """

    def normalize_header(text: str) -> str:
        if not text:
            return ""
        t = str(text)
        t = re.sub(r"\s+", " ", t).strip()
        # нормализация контейнеров и веса
        t = t.replace("’", "'")
        t = t.replace("“", '"').replace("”", '"')
        lower = t.lower()
        # ключи
        is_20dc = "20'dc" in lower or "20dc" in lower
        is_40hc = "40'hc" in lower or "40hc" in lower
        lt_24 = "<24" in lower
        gt_24 = ">24" in lower
        lt_28 = "<28" in lower
        if is_20dc and lt_24:
            return "20DC_lt24t"
        if is_20dc and gt_24:
            return "20DC_gt24t"
        if is_40hc and lt_28:
            return "40HC_lt28t"
        # fallback по явным названиям
        if is_20dc:
            return "20DC"
        if is_40hc:
            return "40HC"
        return ''
        #return re.sub(r"[^A-Za-zА-Яа-я0-9_]+", "_", lower).strip("_") or "col"

    def normalize_price(val):
        if pd.isna(val):
            return None
        s = str(val)
        # вытащим числа
        digits = re.sub(r"[^0-9]", "", s)
        if not digits:
            return None
        try:
            return int(digits)
        except Exception:
            return None
    
    results = []

    # находим строку базовых заголовков (содержит "Пункт отправления" и/или "Станция назначения")
    base_header_row = 0
    for ridx in range(min(20, len(df))):
        row_vals = df.iloc[ridx, :].astype(str).str.strip().tolist()
        joined = " ".join(row_vals).lower()
        if "пункт отправления" in joined or "станция назначения" in joined:
            base_header_row = ridx
            break
    if base_header_row is None:
        raise ValueError("Не удалось найти строку заголовков тарифной таблицы.")

    # соберём многострочные заголовки: возьмём базовую строку и 3 строки ниже/выше для конкатенации
    header_rows = list(range(max(0, base_header_row - 2), min(df.shape[0], base_header_row + 3)))
    headers_concat = []
    for c in range(df.shape[1]):
        parts = []
        for r in header_rows:
            val = df.iat[r, c]
            if pd.notna(val) and str(val).strip():
                parts.append(str(val).strip())
        headers_concat.append(" ".join(parts).strip())

    # определим начало данных
    data_start = base_header_row + 1

    # нормализуем заголовки и карту оригиналов
    normalized_keys = {}

    for c, h in enumerate(headers_concat):
        key = normalize_header(h)
        if key:
            normalized_keys[c] = key

    # ожидаем, что первые две колонки — origin/destination
    origin_col = 0
    destination_col = 1
    price_cols = [i for i in range(2, df.shape[1])]

    
    current_origin = None
    for ridx in range(data_start, df.shape[0]):
        row = df.iloc[ridx, :]
        # обновляем origin, если заполнен
        ov = row.iat[origin_col] if origin_col < len(row) else None
        if pd.notna(ov) and str(ov).strip():
            current_origin = str(ov).strip()
        # читаем destination
        dv = row.iat[destination_col] if destination_col < len(row) else None
        destination = str(dv).strip() if pd.notna(dv) and str(dv).strip() else None
        # соберём цены
        prices = {}
        any_price = False
        for c in price_cols:
            val = row.iat[c] if c < len(row) else None
            price = normalize_price(val)
            key = normalized_keys.get(c, None) or normalized_keys.get(c+1)
            if price is not None:
                prices[key] = price
                any_price = True
        # если есть хоть одна цена и задана destination — фиксируем запись
        if any_price and destination:
            results.append({
                "origin": current_origin.replace("\n",' '),
                "destination": destination.replace("\n",''),
                "prices": prices,
                #"raw_headers": {k: raw_by_key.get(k) for k in prices.keys()},
            })

    if output_json:
        with open(output_json, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

    return results

def parse_EuroSib():
    company = "EuroSib"
    tables, extra_info = get_tables_pdf(url="https://cont.eurosib.biz/files/shipping/sea%20line%20tariffs.pdf", path="download/sea_line_tariffs.pdf", company="EuroSib")
    shedule_json = get_shedule_EuroSib("https://cont.eurosib.biz/download-freight-shedule", "download/download-freight-shedule.xlsx")
    results_table_A1 = []
    rows_table_A1 = []
    rows_table_A2 = []
    rows_table_JD = []
    for table in tables[:2]:
        if not table.empty:
            rows_table_A1 += table.to_dict(orient="records")
    for table in tables[2:3]:
        if not table.empty:
            
            rows_table_A2 += table.to_dict(orient="records")
    for table in tables[3:7]:
        if not table.empty and len(table.to_dict(orient="records")) > 4:
            #print(table.to_dict(orient="records"))
            rows_table_JD += table.to_dict(orient="records")

    json_table_JD = parse_tariff_matrix_to_json(pd.DataFrame(rows_table_JD))
    pods = {"Владивосток": "Морской порт «Первомайский»", "Находка": "Терминал Астафьева", "Владивосток ВМРП": "Владивостокский морской рыбный порт"}

    def get_ETD(port, transshipment):
        results = []
        for key, item in shedule_json.items():
            if port in key or transshipment in key:
                for sydno in item:
                    if sydno.get("ETD", None):
                        results.append(sydno)
        return results
    
    def get_data_table_A1_A2(rows_table, COC_SOC):
        results_table_A1 = []
        for row in rows_table:
            if "Порт отгрузки" == row[0] :
                continue
            n_none = 0
            n_rows = len(row.keys())
            for key, value in row.items():
                if value == None:
                    n_none += 1
            if (n_rows - n_none) <= 3:
                continue
            fo = "FOB" if "FOB" in row[0] else "FOT" if "FOT" in row[0] else ""
            pol_ports = row[0].replace('\n',' ').replace("1", '').replace("FOT", '').replace("FOB", '').strip().split(" / ")
            transshipment = row[1] or row[2]
            dc_20 = row[2] if row[2] and ("$" in row[2] or "По запросу" in row[2]) else row[3]
            if len(row)>=4:
                hc_40 = row[3] if row[3] and ("$" in row[3] or "По запросу" in row[3]) else row[4] if "$" in row[4] or "По запросу" in row[4] else row[5]
            else:
                hc_40 = row[3] if row[3] and ("$" in row[3] or "По запросу" in row[3]) else ''
            currency = "$"
            costs = [dc_20.replace(currency, '').replace(" ", '').strip(), hc_40.replace(currency, '').replace(" ", '').strip()]
            
            for pol_port_i in pol_ports:
                for i in range(2):
                    if costs[i] == "Позапросу" or fo == "FOT":
                        continue
                    for pod_port, pod in pods.items():
                        pol_port = port_dict.get(pol_port_i, pol_port_i)
                        
                        transshipment = port_dict.get(transshipment, transshipment)
                        shedules = get_ETD(pol_port, transshipment)
                        for shedule in shedules:
                            results_table_A1.append({
                                "transport_type": "sea",
                                "start_point": f"{pol_port}, {get_country(pol_port)}",
                                "end_point": f"{pod_port}, {get_country(pod_port)}",
                                "final_destination": f"All, {get_country(pod_port)}",
                                "container_type": "20DC" if i==0 else "40HC",
                                "weight_limit": container_size_dict.get("20DC") if i==0 else container_size_dict.get("40HC"),
                                "cost": costs[i],
                                "currency": currency_dict.get(currency, "$"),
                                "departure_dates": {},
                                "company": "EuroSib",
                                "customs": (
                                    f"vessel: {shedule['vessel']}\n"
                                    f"voyage_no: {shedule['voyage_no']}\n"
                                    f"CUTOFF: {shedule['CUTOFF']}\n"
                                    f"ETA: {shedule['ETA']}\n"
                                    f"ETD: {shedule['ETD']}\n"
                                    f"terminal: {shedule['terminal']}\n"
                                ),
                                "conditions": f"{fo},\n FILO {COC_SOC},\n transshipment:{transshipment}" + (f", {get_country(transshipment)}," if transshipment != "direct" else ",") + f" POD:{pod}"
                            })
        return results_table_A1
    
    def get_data_table_JD(rows_table):
        results_table = []
        for item in rows_table:
            pol_ports = item.get("origin").split("//")
            destination = item.get("destination")
            if "Станция отправления" == destination:
                continue
            if ":" in destination:
                destination = item.get("destination").split(":")
            pod_ports = destination[1].split("/")
            pod_port = destination[0].strip()
            pol_port = ''
            for port in pol_ports:
                pol_port = ''
                for key,value in pods.items():

                    if value == port.strip():
                        pol_port = key
                        break
                prices = item.get("prices")
                for container_type, cost in prices.items():    
                    for pod in pod_ports:
                        results_table.append({
                                        "transport_type": "rail",
                                        "start_point": f"{pol_port}, {get_country(pol_port)}",
                                        "end_point": f"{pod_port}, {get_country(pod_port)}",
                                        "final_destination": f"All, {get_country(pod_port)}",
                                        "container_type": "20DC" if "20DC" in container_type else "40HC",
                                        "weight_limit": container_size_dict.get("20DC") if "lt24t" in container_type else "28" if "gt24t" in container_type else container_size_dict.get("40HC"),
                                        "cost": cost,
                                        "currency": currency_dict.get("руб"),
                                        "departure_dates": "",
                                        "company": "EuroSib",
                                        "customs": "",
                                        "conditions": f"Станции назначения: {pod.replace('*','').strip()}"
                                    })
        
        return results_table

    rows_A1 = pd.DataFrame(get_data_table_A1_A2(rows_table_A1, "COC"))
    rows_A2 = pd.DataFrame(get_data_table_A1_A2(rows_table_A2, "SOC"))
    rows_JD = pd.DataFrame(get_data_table_JD(json_table_JD))
    rows_all = pd.concat([rows_A1, rows_A2,rows_JD], ignore_index=True)
    return rows_all

# =============================
# 8.1 Парсер «ГрандЛог»
# =============================
def parse_GrandLog_xlsx(filepath: str):
    # Считываем весь Excel в DataFrame без заголовков
    df = pd.read_excel(filepath, header=None, sheet_name="ООО «ГрандЛог»")
    company = "GrandLog"
    # Найдем строки, где начинается новая таблица (по наличию "Станция отправления")
    header_rows = df.index[df.iloc[:, 0] == 'Станция отправления'].tolist()
    tables = []
    #print(header_rows)
    for i, start in enumerate(header_rows):
        # конец таблицы — перед следующей "Станция отправления" или конец файла
        end = header_rows[i + 1] if i + 1 < len(header_rows) else len(df)
        sub_df = df.iloc[start:end].reset_index(drop=True)
        sub_df.columns = sub_df.iloc[0]  # первая строка — это заголовки
        sub_df = sub_df.drop(0).reset_index(drop=True)
        tables.append(sub_df)

    # Объединяем все таблицы
    full_df = pd.concat(tables, ignore_index=True)
    # Преобразуем числовые столбцы
    for col in full_df.columns:
        if col not in ['Станция отправления', 'Станция назначения']:
            full_df[col] = (
                full_df[col]
                .astype(str)
                .str.replace(' ', '', regex=False)
                .str.replace(',', '.', regex=False)
                .astype(float)
            )

    # Группировка по станции отправления → список записей
    result = []
    for station_departure, group in full_df.groupby('Станция отправления'):
        records = group.drop(columns=['Станция отправления']).to_dict(orient='records')
        pol_port = get_city_station(station_departure)
        for record in records:
            station_destinations = record["Станция назначения"].replace(" - ",'-').strip()
            if "/" in station_destinations:
                station_destinations = station_destinations.strip().split("/")
            else:
                station_destinations = [station_destinations]
            for station_destination in station_destinations:
                pod_port = get_city_station(station_destination)
                container_types = ["40ф КТК до 28т","20ф КТК до 24т","20ф КТК с 24т до 28т"]
                for container_type in container_types:
                    result.append({
                        "transport_type": "rail",
                        "start_point": f"{pol_port}, {get_country(pol_port)}",
                        "end_point": f"{pod_port}, {get_country(pod_port)}",
                        "final_destination": f"All, {get_country(pod_port)}",
                        "container_type": "20DC" if "20ф" in container_type else "40HC",
                        "weight_limit": container_size_dict.get("20DC") if "до 24т" in container_type else container_size_dict.get("40HC"),
                        "cost": record[container_type],
                        "currency": currency_dict.get("руб"),
                        "departure_dates": {},
                        "company": company,
                        "customs": "",
                        "conditions": f"Станция отправления: {station_departure}.\nСтанция назначения: {station_destination},\nSOC"
                    })

    return pd.DataFrame(result)

#df_GrandLog = parse_GrandLog_xlsx("Транспортные компании.xlsx")
#with pd.ExcelWriter("tariff_analysis_GrandLog.xlsx") as writer:
#    df_GrandLog.to_excel(writer, sheet_name="Raw Data", index=False)

# =============================
# 8.2 Парсер «ГрандЛог»
# =============================
def parse_GrandLog(filepath: str):
    """
    text_blocks — список строк как после PDF:
    [
        "ООО ...",  # инфо
        "Терминальные услуги...",
        "Станция отправления Станция назначения 40ф ...",
        "Угловая Омск-Восточный 180000 ...",
        ...
    ]
    """
    company = "ООО «ГрандЛог»"
    tables, text_blocks = get_tables_pdf(None, filepath, company)
    # Объединяем всё в один "сырой" текст
    raw = "\n".join(text_blocks)

    # Находим все таблицы по триггеру "Станция отправления"
    table_chunks = re.split(r"(?=Станция отправления)", raw)

    tables = []

    for chunk in table_chunks:
        if "Станция отправления" not in chunk:
            continue

        lines = [l.strip() for l in chunk.split("\n") if l.strip()]

        # Первая строка — заголовки
        header_line = lines[0]
        headers = header_line.split()
        # Пример: ["Станция", "отправления", "Станция", "назначения", "40ф", "КТК", "до", "28т", ...]

        # Нормализуем заголовки
        normalized_headers = []
        i = 0
        while i < len(headers):
            word = headers[i]

            # Склеиваем составные заголовки
            if word == "Станция" and i + 1 < len(headers) and headers[i + 1] in ["отправления", "назначения"]:
                normalized_headers.append(f"{word} {headers[i+1]}")
                i += 2
                continue

            # Склеиваем "40ф КТК до 28т"
            if "ф" in word and i + 3 < len(headers) and headers[i+1] == "КТК" and headers[i+2] == "до":
                container_header = f"{word} {headers[i+1]} {headers[i+2]} {headers[i+3]}"
                normalized_headers.append(container_header)
                i += 4
                continue

            if "ф" in word and i + 5 < len(headers) and headers[i+1] == "КТК" and headers[i+2] == "с":
                container_header = f"{word} {headers[i+1]} {headers[i+2]} {headers[i+3]} {headers[i+4]} {headers[i+5]}"
                normalized_headers.append(container_header)
                i += 6
                continue
            normalized_headers.append(word)
            i += 1
        # Читаем строки данных
        data_rows = []
        for line in lines[1:]:
            
            parts = line.split()
            if "Ставки" in parts or "+7" in parts or "по" in parts:
                continue
            
            if len(parts) < 3:
                continue

            # Нормализуем строки, склеиваем станции
            station_from = parts[0]
            station_to = parts[1]
            indx_cost = 2
            if not parts[2].isdigit() and "," not in parts[2]:
                station_to += " " + parts[2]
                indx_cost = 3
            # Остальные значения — цены
            values = parts[indx_cost:]

            costs = []
            for index_cost in range(len(values)):
                cost = values[index_cost]
                cost = cost.replace(",",".")
                c_ = float(cost)
                if c_ == 0.0:
                    costs.append(values[index_cost-1]+values[index_cost])
                elif len(cost) >= 6:
                    costs.append(values[index_cost])

            row = [station_from, station_to] + costs
            data_rows.append(row)

        df = pd.DataFrame(data_rows, columns=normalized_headers)
        tables.append(df)

    # Объединяем все найденные таблицы
    full_df = pd.concat(tables, ignore_index=True)

    # Числовые поля приводим к float
    for col in full_df.columns:
        if "Станция" in col:
            continue
        full_df[col] = (
            full_df[col]
            .astype(str)
            .str.replace(" ", "", regex=False)
            .str.replace(",", ".", regex=False)
            .str.replace(" ", "", regex=False)
        )
        full_df[col] = pd.to_numeric(full_df[col], errors="coerce")

    # ========================================================
    # Формируем итоговую структуру
    # ========================================================

    container_map = {
        "40ф КТК до 28т": ("40HC", "28"),
        "20ф КТК до 24т": ("20DC", "24"),
        "20ф КТК с 24т до 28т": ("20DC", "28"),
    }

    result = []

    for _, row in full_df.iterrows():
        pods_ = row["Станция назначения"] + "/"
        for pod_ in pods_.split("/"):
            if pod_ == "" or pod_ == None:
                continue
            pol = get_city_station(row["Станция отправления"])
            pod = get_city_station(pod_)

            for container_header, (ctype, weight) in container_map.items():
                if container_header not in full_df.columns:
                    continue

                cost = row[container_header]
                if pd.isna(cost):
                    continue

                result.append({
                    "transport_type": "rail",
                    "start_point": f"{pol}, {get_country(pol)}",
                    "end_point": f"{pod}, {get_country(pod)}",
                    "final_destination": f"All, {get_country(pod)}",

                    "container_type": ctype,
                    "weight_limit": weight,

                    "cost": float(cost),
                    "currency": "RUB",

                    "departure_dates": {},
                    "company": company,

                    "customs": "",
                    "conditions": f"Станция отправления: {pol}.\nСтанция назначения: {pod}.\n SOC"
                })

    return pd.DataFrame(result)

# =============================
# 9. Парсер TML
# =============================
def parse_TML(filepath: str):
	# Считываем весь Excel в DataFrame без заголовков
	company="TML"
	df = pd.read_excel(filepath, header=None, sheet_name=company)
	
	result = []
	data = df.iloc[0,0].split('===')
	sea_rail = data[0].split("\n")
	direct_railway_lines = data[1].split("\n")
	for line in range(0,len(sea_rail)-1,3):
		if "FOB" in sea_rail[line]:
			d = sea_rail[line].split(" - ")
			pol_list = d[0].replace("FOB",'').replace("/"," /").strip().split(" / ")
			pod_cost = d[1].split(" = ")
			pod_container_type = pod_cost[0].split()
			pod = pod_container_type[1]
			container_type = pod_container_type[2]
			cost = pod_cost[1]
			drop_off = sea_rail[line+1].split(" -")
			pol_jd = drop_off[0].replace("CY ", "").strip().title()
			pod_jd = drop_off[1].split(" = ")[0].replace("FOR",'').strip().title()
			cost_jd = float(drop_off[1].split(" = ")[1].replace(" ",'').strip())
			pod_jd = region_dict.get(pod_jd, pod_jd)
			pol_jd = port_dict.get(pol_jd, pol_jd)
			for pol in pol_list:
				pol_port = port_dict.get(pol.strip().title(), pol.strip().title())
				pod_port = port_dict.get(pod.strip().title(), pod.strip().title())
				
				result.append({
					"transport_type": "sea",
					"start_point": f"{pol_port}, {get_country(pol_port)}",
					"end_point": f"{pod_port}, {get_country(pod_port)}",
					"final_destination": f"{pod_jd}, {get_country(pod_port)}",
					"container_type": container_type.strip(),
					"weight_limit": container_size_dict.get(container_type.strip()),
					"cost": cost.split()[0].strip(),
					"currency": currency_dict.get("$") if "USD" in cost else currency_dict.get("руб"),
					"departure_dates": "",
					"company": company,
					"customs": "",
					"conditions": f"FOB, порт: {pod.strip().title()}"
				})
			result.append({
					"transport_type": "rail",
					"start_point": f"{pol_jd}, {get_country(pol_jd)}",
					"end_point": f"{pod_jd}, {get_country(pod_jd)}",
					"final_destination": f"{pod_jd}, {get_country(pod_port)}",
					"container_type": container_type.strip(),
					"weight_limit": container_size_dict.get(container_type.strip()),
					"cost": cost_jd,
					"currency": currency_dict.get("руб"),
					"departure_dates": "",
					"company": company,
					"customs": "",
					"conditions": ""
				})
	for line in direct_railway_lines:
		if "FOB" in line:
			d = line.replace("FOB", "").strip().split(":")
			pol_pod_list = d[0].split("-")
			cost_container_type = d[1].split("/")
			pol_jd = port_dict.get(pol_pod_list[0].strip().title(), pol_pod_list[0].strip().title())
			pod_jd = region_dict.get(pol_pod_list[-1].strip().title(), pol_pod_list[-1].strip().title())
			container_type = cost_container_type[1].strip()
			cost_jd = cost_container_type[0].replace("USD",'').replace("RUB",'')
			result.append({
					"transport_type": "rail",
					"start_point": f"{pol_jd}, {get_country(pol_jd)}",
					"end_point": f"{pod_jd}, {get_country(pod_jd)}",
					"final_destination": f"All, {get_country(pod_port)}",
					"container_type": container_type,
					"weight_limit": container_size_dict.get(container_type),
					"cost": cost_jd,
					"currency": currency_dict.get("$") if "USD" in cost_container_type[0] else currency_dict.get("руб"),
					"departure_dates": "",
					"company": company,
					"customs": "",
					"conditions": d[0]
				})


	#print(result)
	return pd.DataFrame(result)

# =============================
# 10. Парсер G&W CHINA LIMITED
# =============================
def parse_GW_CHINA_LIMITED(file_path: str):
	company="G&W CHINA LIMITED"
	df = pd.read_excel(file_path, sheet_name=company)
	df = df.fillna("")

	results = []

	current_departure = ""
	current_destination = ""
	current_etd = ""
	current_tt = ""

	for _, row in df.iterrows():
		dep = str(row["Departure Station"]).strip()
		dest = str(row["Destination"]).strip()
		pickup = str(row["Pick-up City"]).strip()
		rate = str(row["Rate/40HQ(USD)"]).strip()
		tt = str(row["T/T"]).strip()

        # если в строке указано новое направление — обновляем контекст
		if dep:
			current_departure = dep
			# вычленяем дату ETD, если указано
			etd_match = re.search(r"ETD[:\s]*(.+)", dep, re.I)
			if etd_match:
				current_etd = etd_match.group(1).strip()
				current_departure = re.sub(r"ETD[:\s]*.+", "", dep, flags=re.I).strip()
			else:
				current_etd = ""

		if dest:
			current_destination = dest

		if tt:
			current_tt = tt

        # если есть ставка и pick-up — добавляем запись
		if rate and pickup:
			cost = re.sub(r"[^\d.]", "", rate)
			pol_port = port_dict.get(pickup.strip().title(), pickup.strip().title())
			current_destination_list = current_destination.split("Via")
			pod_port = region_dict.get(current_destination_list[0].strip().title(), current_destination_list[0].strip().title())
			entry = {
				"transport_type": "rail",
				"start_point": f"{pol_port}, {get_country(pol_port)}",
				"end_point": f"{pod_port}, {get_country(pod_port)}",
				"final_destination": f"All, {get_country(pod_port)}",
				"container_type": "40HQ",
				"weight_limit": container_size_dict.get("40HQ"),
				"cost": cost,
				"currency": currency_dict.get("$"),
				"departure_dates": {current_etd} if current_etd else {},
				"company": "G&W CHINA LIMITED",
				"customs": "",
				"conditions": f"Via {current_destination_list[1].strip()},\n Transit time: {current_tt}" if current_tt else "",
			}
			results.append(entry)

	return pd.DataFrame(results)

# =============================
# 11. Парсер Shenzhen Eagleway Supply Chain Management
# =============================
def parse_Shenzhen_Eagleway_Supply_Chain_Management(file_path: str):
	company = "Shenzhen Eagleway Supply Chain Management"
	df = pd.read_excel(file_path, sheet_name = "Shenzhen Eagleway Supply Chain ")
	df = df.fillna("")

	results = []

	current_departure = ""
	current_border = ""
	current_unloading = ""
	current_etd = ""

	for _, row in df.iterrows():
		loading_city = str(row.get("Loading City", "")).strip()
		departure = str(row.get("Departure", "")).strip()
		border = str(row.get("CN BORDER", "")).strip()
		unloading = str(row.get("Unloading", "")).strip()
		rate = str(row.get("USD / 40HQ", "")).strip()
		etd = str(row.get("ETD", "")).strip()

		# Если в строке указано новое направление — обновляем контекст
		if departure:
			current_departure = departure
		if border:
			current_border = border
		if unloading:
			current_unloading = unloading
		if etd:
			current_etd = etd

		# Если есть ставка и город погрузки — добавляем запись
		if rate and loading_city:
			cost = re.sub(r"[^\d.]", "", rate)
			loading_city = loading_city.replace("FOB", '').strip()
			pol_port = port_dict.get(loading_city.strip().title(), loading_city.strip().title())
			current_unloading_list = current_unloading.split("(")
			pod_port = region_dict.get(current_unloading_list[0].strip().title(), current_unloading_list[0].strip().title())
			station = current_unloading_list[1].split("--")[0].strip()
			entry = {
					"transport_type": "rail",
					"start_point": f"{pol_port}, {get_country(pol_port)}",
					"end_point": f"{pod_port}, {get_country(pod_port)}",
					"final_destination": f"All, {get_country(pod_port)}",
					"container_type": "40HQ",
					"weight_limit": container_size_dict.get("40HQ"),
					"cost": cost,
					"currency": currency_dict.get("$"),
					"departure_dates": {current_etd} if current_etd else {},
					"company": "Shenzhen Eagleway Supply Chain Management",
					"customs": "",
					"conditions": (
						f"Via: {current_border}.\n"
						f"Станция назначения: {station}"
                        f"ETD: {current_etd}" if current_etd else ""
					),
				}
			results.append(entry)
	return pd.DataFrame(results)

# =============================
# 12. Парсер Shenzhen Space logistics
# =============================
def parse_Shenzhen_Space_logistics(file_path: str):
	company = "Shenzhen Space logistics"
	raw = pd.read_excel(file_path, sheet_name = company, header=None)
	raw = raw.fillna("")

	# Находим строку, где начинается таблица (где встречается 'Pickup' или 'Border')
	header_row = None
	for i, row in raw.iterrows():
		joined = " ".join(str(v).lower() for v in row)
		if "pickup" in joined and ("border" in joined or "destination" in joined):
			header_row = i
			break

	if header_row is None:
		raise ValueError("Не удалось найти строку заголовков (header)")

	# Читаем файл снова, теперь с корректной строкой заголовков
	df = pd.read_excel(file_path, header=header_row, sheet_name = company,)
	df = df.fillna("")

	# Стандартизируем названия колонок
	df.columns = [str(c).strip().lower() for c in df.columns]

	# Попытка найти подходящие колонки по смыслу
	pickup_col = next((c for c in df.columns if "pickup" in c), None)
	border_col = next((c for c in df.columns if "border" in c), None)
	dest_col = next((c for c in df.columns if "dest" in c), None)
	rate_col = next((c for c in df.columns if "rate" in c or "foB" in c), None)
	tt_col = next((c for c in df.columns if "t/t" in c), None)
	etd_col = next((c for c in df.columns if "etd" in c), None)

	results = []
	current_border = ""
	current_destination = ""
	current_tt = ""
	current_etd = ""

	for _, row in df.iterrows():
		pickup = str(row.get(pickup_col, "")).strip()
		border = str(row.get(border_col, "")).strip()
		destination = str(row.get(dest_col, "")).strip()
		rate = str(row.get(rate_col, "")).strip()
		tt = str(row.get(tt_col, "")).strip()
		etd = str(row.get(etd_col, "")).strip()

		if border:
			current_border = border
		if destination:
			current_destination = destination
		if tt:
			current_tt = tt
		if etd:
			current_etd = etd

		if rate and pickup:
			cost = re.sub(r"[^\d.]", "", rate)
			pickups = (pickup.replace("area",'').strip()+"/").split("/")
			for pickup in pickups:
				if pickup:
					pol_port = port_dict.get(pickup.strip().title(), pickup.strip().title())
					pod_port = region_dict.get(current_destination.strip().title(), current_destination.strip().title())
					
					entry = {
						"transport_type": "rail",
						"start_point": f"{pol_port}, {get_country(pol_port)}",
						"end_point": f"{pod_port}, {get_country(pod_port)}",
						"final_destination": f"All, {get_country(pod_port)}",
						"container_type": "40HQ",
						"weight_limit": container_size_dict.get("40HQ"),
						"cost": cost,
						"currency": currency_dict.get("$"),
						"departure_dates": {current_etd} if current_etd else {},
						"company": "Shenzhen Space Logistics",
						"customs": "",
						"conditions": (
							f"Via: {current_border}"
                            f"Transit time: {current_tt}" if current_tt else ""
						),
					}
					results.append(entry)

	return pd.DataFrame(results)

# =============================
# 13. Парсер LCL
# =============================
def parse_LCL(file_path: str):
	"""
	Robust LCL parser v2.
	- Объединяет все ячейки строки в одну строку.
	- Пробует несколько regex-шаблонов и fallback-стратегий.
	- Пишет debug CSV с исходной строкой и извлечёнными полями.
	Возвращает pd.DataFrame со стандартными полями.
	"""
	df_raw = pd.read_excel(file_path, header=None, dtype=str, sheet_name = "LCL").fillna("")
	results = []
	debug_rows = []

	# helper funcs
	def norm_amount(s):
		if not s:
			return ""
		s = str(s)
		s = s.replace("\u00A0", "").replace(" ", "")
		m = re.search(r"(\d+(?:[.,]\d+)?)", s)
		if not m:
			return ""
		return m.group(1).replace(",", ".")

	def norm_currency(s):
		if not s:
			return ""
		s = str(s).upper()
		if "$" in s or "USD" in s or "US$" in s:
			return "USD"
		if "РБ" in s or "RUB" in s or "РУБ" in s:
			return "RUB"
		if "€" in s or "EUR" in s:
			return "EUR"
		return ""

	# Patterns: several attempts with decreasing strictness
	patterns = [
		# full pattern: FOB start to end R/F: USD 4400 /40HQ
		re.compile(
			r"""^\s*FOB\s+
				(?P<start>.+?)\s+to\s+
				(?P<end>.+?)\s+
				(?:R/?F[:\s]*)?
				(?:(?P<cur>USD|US\$|\$|EUR|€|RUB|руб)\s*)?
				(?P<amount>[\d\s,\.]+)?
				(?:\s*(?:/|per)?\s*(?P<cont>40HQ|40HC|20GP|20DC|40FT|40'))?
				\s*$""",
			flags=re.I | re.X,
		),
		# simpler: FOB start to end ... USD 4400
		re.compile(r"^\s*FOB\s+(?P<start>.+?)\s+to\s+(?P<end>.+?)\b.*?(?P<cur>USD|\$|EUR|€|RUB|руб)?\s*(?P<amount>\d{3,6}(?:[.,]\d+)?)", flags=re.I),
		# fallback: start after FOB, everything before R/F or price is route
		re.compile(r"^\s*FOB\s+(?P<route>.+?)\s+(?:R/?F[:\s]*)?(?P<cur>USD|\$|EUR|€|RUB|руб)?\s*(?P<amount>\d{3,6}(?:[.,]\d+)?)", flags=re.I),
	]

	for idx, row in df_raw.iterrows():
		# join cells into single line (preserve order). filter empty cells.
		parts = [str(x).strip() for x in row.tolist() if str(x).strip() != ""]
		if not parts:
			continue
		line = " ".join(parts)
		line = re.sub(r"\s+", " ", line).strip()

		# Some rows might be header-like or unrelated; only process lines that contain "FOB" or "R/F"
		if not re.search(r"\bFOB\b", line, flags=re.I):
			# still keep debug row for visibility
			debug_rows.append({"idx": idx, "line": line, "matched": False, "reason": "no FOB"})
			continue

		start_point = ""
		end_point = ""
		amount = ""
		currency = ""
		container = ""
		used_pattern = None

		# Try patterns in order
		for p in patterns:
			m = p.search(line)
			if not m:
				continue
			used_pattern = p
			gd = m.groupdict()
			# Map possible groups
			if gd.get("start"):
				start_point = gd.get("start", "") or ""
			if gd.get("end"):
				end_point = gd.get("end", "") or ""
			# route style: may contain "X/Y to Z"
			if not start_point and gd.get("route"):
				# try split route 'A to B' inside route
				route = gd.get("route", "")
				m2 = re.search(r"(.+?)\s+to\s+(.+)", route, flags=re.I)
				if m2:
					start_point = m2.group(1).strip()
					end_point = m2.group(2).strip()
				else:
					# maybe 'Shanghai/Suzhou to Selyatino' already in route - try splitting by 'to'
					parts_route = route.split(" to ")
					if len(parts_route) >= 2:
						start_point = parts_route[0].strip()
						end_point = parts_route[1].strip()
					else:
						start_point = route.strip()

			# amount/currency/container
			amount_raw = gd.get("amount") or ""
			if amount_raw:
				amount = norm_amount(amount_raw)
			cur_raw = gd.get("cur") or ""
			if cur_raw:
				currency = norm_currency(cur_raw)
			cont_raw = gd.get("cont") or ""
			if cont_raw:
				container = cont_raw.upper().replace("'", "").replace("FT", "HQ")

			# break at first successful
			if start_point or amount:
				break

		# Additional heuristics if not enough extracted:
		if not end_point:
			# try to find " to <END> R/F" positions
			m_to = re.search(r"\bto\s+([A-Za-zА-Яа-я0-9/\-\s()]+?)(?:\s+R/?F\b|\s+\$|\s+\d{3})", line, flags=re.I)
			if m_to:
				end_point = m_to.group(1).strip()

			if not start_point:
				m_start = re.search(r"FOB\s+(.+?)\s+(?:to\b|R/?F\b|\$|\d{3})", line, flags=re.I)
				if m_start:
					start_point = m_start.group(1).strip()

		if not amount:
			# search for price after 'R/F' or any number
			m_price = re.search(r"(?:R/?F[:\s]*)?(?:USD|US\$|\$|EUR|€|RUB|руб)?\s*([0-9]{3,6}(?:[ ,\.][0-9]{3})*(?:[.,][0-9]+)?)", line, flags=re.I)
			if m_price:
				amount = norm_amount(m_price.group(1))
				# try find currency near number
				left_context = line[:m_price.start()+10]
				m_cur = re.search(r"(USD|US\$|\$|EUR|€|RUB|руб)", left_context, flags=re.I)
				if not m_cur:
					m_cur = re.search(r"(USD|US\$|\$|EUR|€|RUB|руб)", line, flags=re.I)
				if m_cur:
					currency = norm_currency(m_cur.group(1))

		if not container:
			m_cont = re.search(r"(40HQ|40HC|20GP|20DC|40FT|40')", line, flags=re.I)
			if m_cont:
				container = m_cont.group(1).upper().replace("'", "").replace("FT", "HQ")

		# defaults
		if not container:
			container = "40HQ"
			if not currency:
				# default to USD if line contains $ or USD, else blank
				if re.search(r"\$|USD", line, flags=re.I):
					currency = "USD"
				else:
					currency = ""

		# Clean start/end: remove leading "FOB" remnants
		start_points = re.sub(r"^FOB\s*", "", start_point, flags=re.I).strip()+"/"
		# strip trailing phrases like 'R/F' or rates
		end_point = re.sub(r"\s+R/?F[:\s\S]*$", "", end_point, flags=re.I).strip()
		for start_point in start_points.split("/"):
			if not start_point:
				continue
			pol_port = port_dict.get(start_point.strip().title(), start_point.strip().title())
			pod_port = region_dict.get(end_point.strip().title(), end_point.strip().title())
					
			record = {
				"transport_type": "rail",
				"start_point": f"{pol_port}, {get_country(pol_port)}",
				"end_point": f"{pod_port}, {get_country(pod_port)}",
				"final_destination": f"All, {get_country(pod_port)}",
				"container_type": container,
				"weight_limit": container_size_dict.get(container, ""),
				"cost": amount,
				"currency": currency,
				"departure_dates": {},
				"company": "LCL",
				"customs": "",
				"conditions": f"R/F: {container}\nFOB"
			}
			results.append(record)

	return pd.DataFrame(results)

# =============================
# 14. Парсер Amethyst
# =============================
def parse_Amethyst(file_path: str):
    """
    Парсер таблицы Amethyst (BAF rates).
    Поддерживает маршруты с несколькими портами через '/'.
    Возвращает pd.DataFrame и печатает списки городов, стран и портов.
    """

    df = pd.read_excel(file_path, header=None, sheet_name="Аметист")
    df = df.fillna("")
    results = []

    for _, row in df.iterrows():
        line = " ".join(str(x).strip() for x in row if str(x).strip() != "")
        if not line or "<->" not in line:
            continue

        # Основной шаблон: (XX) Port(s) <-> (YY) Port(s) $ value
        match = re.search(
            r"\((\w{2})\)\s*([^<]+)<->\s*\((\w{2})\)\s*([^\$]+)\$?\s*([\d.,]+)",
            line
        )
        if not match:
            continue

        pol_cc, pol_ports_raw, pod_cc, pod_ports_raw, cost = match.groups()
        cost = re.sub(r"[^\d.]", "", cost)

        # Разбиваем множественные порты (через / или ,)
        pol_ports = re.split(r"[/,]", pol_ports_raw)
        pod_ports = re.split(r"[/,]", pod_ports_raw)

        for pol in pol_ports:
            pol = pol.strip()
            if not pol:
                continue
            for pod in pod_ports:
                pod = pod.strip()
                if not pod:
                    continue

                container_type = "20DC"
                currency = currency_dict.get("$", "USD")

                # Получаем переводы
                pol_port = port_dict.get(pol.title(), pol.title())
                pod_port = port_dict.get(pod.title(), pod.title())

                start_country = get_country(pol_port)
                end_country = get_country(pod_port)

                record = {
                    "transport_type": "sea",
                    "start_point": f"{pol_port}, {start_country}",
                    "end_point": f"{pod_port}, {end_country}",
                    "final_destination": f"All, {end_country}",
                    "container_type": container_type,
                    "weight_limit": container_size_dict.get(container_type, ""),
                    "cost": cost,
                    "currency": currency,
                    "departure_dates": {},
                    "company": "Amethyst",
                    "customs": "",
                    "conditions": "BAF per TEU"
                }
                results.append(record)

    return pd.DataFrame(results)

# =============================
# 15. Парсер Hesion Global Logistics
# =============================
def parse_Hesion_Global_Logistics(file_path: str):
    """
    Парсер тарифов Hesion Global Logistics.
    Возвращает pd.DataFrame в унифицированном формате для main.py.
    """
    df = pd.read_excel(file_path, sheet_name = "Hesion-globallogistics")
    df = df.fillna("")

    results = []

    current_carrier = ""
    current_pod = ""

    for _, row in df.iterrows():
        carrier = str(row.get("CARRIER", "")).strip()
        pol = str(row.get("POL", "")).strip()
        pod = str(row.get("POD", "")).strip()
        rate_20 = str(row.get("20GP", "")).strip()
        rate_40 = str(row.get("40HQ", "")).strip()
        etd = str(row.get("ETD", "")).strip()
        remark = str(row.get("REMARK", "")).strip()
        route = str(row.get("Route", "")).strip()

        # Наследуем предыдущие значения, если пустые
        if carrier:
            current_carrier = carrier
        else:
            carrier = current_carrier

        if pod:
            current_pod = pod
        else:
            pod = current_pod

        # Определяем валюту
        currency = currency_dict.get("$", "USD")
        pod_list = pod.split()
        pod = pod_list[0]

        # Базовые преобразования портов
        pol_port = port_dict.get(pol.title(), pol.title())
        pod_port = region_dict.get(pod.title(), pod.title())

        start_country = get_country(pol_port)
        end_country = get_country(pod_port)

        # Создаём записи по типам контейнеров
        for container_type, rate in [("20GP", rate_20), ("40HQ", rate_40)]:
            if not rate:
                continue
            # возможны значения вроде 4250/4550 — делим на 2 ставки
            rates = re.split(r"[ /]+", rate)
            for cost in rates:
                cost = re.sub(r"[^\d.]", "", cost)
                if not cost:
                    continue

                record = {
                    "transport_type": "sea",
                    "start_point": f"{pol_port}, {start_country}",
                    "end_point": f"{pod_port}, {end_country}",
                    "final_destination": f"All, {end_country}",
                    "container_type": container_type,
                    "weight_limit": container_size_dict.get(container_type, ""),
                    "cost": cost,
                    "currency": currency,
                    "departure_dates": {etd} if etd else {},
                    "company": "Hesion Global Logistics",
                    "customs": "",
                    "conditions": (
                        f"Перевозчик: {carrier}\n"
                        f"Порт отправления: {pol_port}\n"
                        f"Порт назначения: {pod_port} {pod_list[1]}\n"
                        f"Комментарий: {remark}"
                        f"{route}".replace("，", ",").strip()
                    ),
                }
                results.append(record)

    return pd.DataFrame(results)

# =============================
# 16. Парсер NingBo Y-STAR Logistics
# =============================
def parse_NingBo_YSTAR_Logistics(file_path: str):
    """
    Парсер тарифов компании NingBo Y-STAR Logistics.
    Обрабатывает многостраничную таблицу с несколькими блоками Carrier/POL/POD.
    Возвращает pd.DataFrame, готовый к объединению в main.py.
    """

    # читаем всё без заголовков (так как они повторяются)
    df = pd.read_excel(file_path, header=None, sheet_name = "NingBo Y-STAR Logistics")
    df = df.fillna("")

    results = []

    current_carrier = ""
    current_pod = ""

    # заголовки таблицы (чтобы определять начало нового блока)
    header_pattern = re.compile(r"(?i)carrier\s*")

    # преобразуем всё в список строк
    rows = df.values.tolist()

    # найдём индексы начала новых таблиц
    table_starts = [i for i, r in enumerate(rows) if any(header_pattern.search(str(c)) for c in r)]
    table_starts.append(len(rows))
    free_time_set = {}
    for t in range(len(table_starts) - 1):
        start = table_starts[t] + 1
        end = table_starts[t + 1]
        block = pd.DataFrame(rows[start:end])
        block.columns = [
            "Carrier", "POL", "POD", "20GP (USD)", "40HQ (USD)",
            "TERM", "Free time", "ETD", "V/V"
        ][:len(block.columns)]
        block = block.fillna("")

        for _, row in block.iterrows():
            carrier = str(row.get("Carrier", "")).strip()
            pol = str(row.get("POL", "")).strip()
            pod = str(row.get("POD", "")).strip()
            rate_20 = str(row.get("20GP (USD)", "")).strip()
            rate_40 = str(row.get("40HQ (USD)", "")).strip()
            term = str(row.get("TERM", "")).strip()
            free_time = str(row.get("Free time", "")).strip()
            etd = str(row.get("ETD", "")).strip()
            vv = str(row.get("V/V", "")).strip()
            if carrier not in free_time_set.keys():
                free_time_set[carrier] = {}
            free_time_set[carrier]["vv"] = vv if vv else free_time_set.get(carrier).get('vv')
            free_time_set[carrier]["term"] = vv if vv else free_time_set.get(carrier).get('term')
            free_time_set[carrier]["free_time"] = free_time if free_time else free_time_set.get(carrier).get("free_time")
            # Наследуем carrier и pod если они пустые
            if carrier:
                current_carrier = carrier
            else:
                carrier = current_carrier
            if pod:
                current_pod = pod
            else:
                pod = current_pod

            # если нет POL — пропускаем
            if not pol:
                continue

            currency = currency_dict.get("$", "USD")
            if "(" in pol:
                pol_list = pol.split("(")
                pol = pol_list[0]
            pol_port = port_dict.get(pol.title(), pol.title())
            pod_port = port_dict.get(pod.title(), pod.title())

            start_country = get_country(pol_port)
            end_country = get_country(pod_port)

            for container_type, rate in [("20GP", rate_20), ("40HQ", rate_40)]:
                if not rate or rate == "*":
                    continue
                for cost in re.split(r"[ /]+", rate):
                    cost = re.sub(r"[^\d.]", "", cost)
                    if not cost:
                        continue

                    record = {
                        "transport_type": "sea",
                        "start_point": f"{pol_port}, {start_country}",
                        "end_point": f"{pod_port}, {end_country}",
                        "final_destination": f"Все, {end_country}",
                        "container_type": container_type,
                        "weight_limit": container_size_dict.get(container_type, ""),
                        "cost": cost,
                        "currency": currency,
                        "departure_dates": {etd} if etd else {},
                        "company": "NingBo Y-STAR Logistics",
                        "customs": (
                            f"Перевозчик: {carrier}\n"
                            f"Порт отправления: {pol_port}\n"
                            f"Порт назначения: {pod_port}\n"
                            f"Свободное время: {free_time_set.get(carrier).get('free_time')}\n"
                            f"Примечание: {free_time_set.get(carrier).get('term')}\n"
                            f"Судно/рейс: {free_time_set.get(carrier).get('vv')}"
                        ),
                        "conditions": f"{free_time_set.get(carrier).get('term')}".replace("\n", " ").strip()
                    }
                    results.append(record)

    return pd.DataFrame(results)

# =============================
# 17. Парсер Неизвестная компания_1
# =============================
def parse_UnknownCompany1(file_path: str):
    df = pd.read_excel(file_path, header=None, sheet_name = "Неизвестная компания_1")
    text = " ".join(str(x) for x in df.values.flatten() if str(x).strip())
    text = re.sub(r"\s+", " ", text).strip()

    results = []

    # Извлекаем маршрут
    route_match = re.search(r"Маршрут[:：]?\s*(.+?)Расчет", text, re.IGNORECASE)
    route = route_match.group(1).strip() if route_match else ""
    # Пример: "станция Чанша -- граница Маньчжурии -- Белый Раст"
    parts = re.split(r"--|–|-", route)
    pol_route = parts[0].strip() if parts else "Китай"
    pod_route = parts[-1].strip() if len(parts) > 1 else "Россия"

    # Извлекаем все POL и ставки
    pol_rates = re.findall(r"POL[:：]?\s*([^\d]+)\s*([\d]+)", text)

    # Доп. инфа
    extra = ""
    if "Разрешена" in text:
        extra = re.search(r"(Разрешена[^.]+[.]?)", text)
        extra = extra.group(1) if extra else ""

    # Контейнер
    container_type = "40HQ"
    currency = currency_dict.get("$", "USD")

    for pol_raw, cost in pol_rates:
        pol_ = pol_raw.strip().strip(":：") + "/"
        cost = cost.strip()
        for pol in pol_.split("/"):
            if pol:       
                pol_port = port_dict.get(pol.title(), pol.title())
                pod_port = region_dict.get(pod_route.title(), pod_route.title())

                start_country = get_country(pol_port)
                end_country = get_country(pod_port)

                record = {
                    "transport_type": "rail",
                    "start_point": f"{pol_port}, {start_country}",
                    "end_point": f"{pod_port}, {end_country}",
                    "final_destination": f"All, {end_country}",
                    "container_type": container_type,
                    "weight_limit": container_size_dict.get(container_type, ""),
                    "cost": cost,
                    "currency": currency,
                    "departure_dates": {},
                    "company": "UnknownCompany1",
                    "customs": "",
                    "conditions": (
                        f"Маршрут: {route}\n"
                        f"Порт отправления: {pol_port}\n"
                        f"Порт назначения: {pod_port}\n"
                        f"{extra}"
                        "FOB, разрешена перевозка батарей"
                    ),
                }
                results.append(record)

    return pd.DataFrame(results)

# =============================
# 18. Парсер Spacelog
# =============================
def parse_Spacelog(file_path: str):
    df = pd.read_excel(file_path, sheet_name = "Spacelog", header = None)
    df = df.fillna("")

    results = []
    dest_old = ''
    tt_old = ''
    etd_old = ''
    for _, row in df.iterrows():
        pickup = str(row.get("Pickup city", "") or row[0]).strip()
        border = str(row.get("Border", "") or row[2]).strip()
        dest = str(row.get("Destination station", "") or row[3]).strip()
        rate = str(row.get("FOB R/F rate", "") or row[4]).strip()
        tt = str(row.get("T/T", "") or row[5]).strip()
        etd = str(row.get("ETD", "") or row[6]).strip()
        # если нет pickup или ставки — пропускаем
        if not pickup or not rate:
            continue

        # обработка ставки
        cost_match = re.search(r"([\d,.]+)", rate)
        if not cost_match:
            continue
        cost = re.sub(r"[^\d.]", "", rate)
        currency = currency_dict.get("$", "USD")

        # контейнер
        container_type = "40HQ"
        if not dest_old or dest:
            dest_old = dest
        if not etd_old or etd:
            etd_old = etd
        if not tt_old or tt:
            tt_old = tt
        # Обработка многочастных значений
        pickup_ports = re.split(r"[/,]", pickup)
        borders = re.split(r"[/,]", border) if border else [""]
        destinations = re.split(r"[/,]", dest) if dest else [dest_old]

        for pol_raw in pickup_ports:
            pol = pol_raw.strip()
            if not pol:
                continue
            pol = pol.replace(" area","")
            for border_name in borders:
                border_name = border_name.strip()
                for pod_raw in destinations:
                    pod = pod_raw.strip() if pod_raw else "Москва"

                    pol_port = port_dict.get(pol.title(), pol.title())
                    pod_port = region_dict.get(pod.title(), pod.title())

                    start_country = get_country(pol_port)
                    end_country = get_country(pod_port)

                    record = {
                        "transport_type": "rail",
                        "start_point": f"{pol_port}, {start_country}",
                        "end_point": f"{pod_port}, {end_country}",
                        "final_destination": f"All, {end_country}",
                        "container_type": container_type,
                        "weight_limit": container_size_dict.get(container_type, ""),
                        "cost": cost,
                        "currency": currency,
                        "departure_dates": {etd_old} if etd_old else {},
                        "company": "Spacelog",
                        "customs": "",
                        "conditions": (
                            f"Пограничный переход: {border_name}\n"
                            f"Время в пути: {tt_old}\n"
                            f"Отправление: {etd_old}"
                            "FOB, железнодорожная перевозка"
                        )
                    }
                    results.append(record)

    return pd.DataFrame(results)

# =============================
# 19. Парсер Shenzhen Wotu International
# =============================
def parse_Shenzhen_Wotu_International(file_path: str):
    df = pd.read_excel(file_path, header=None, sheet_name = "Shenzhen Wotu International")
    lines = [str(x).strip() for x in df.values.flatten() if str(x).strip()]
    results = []

    combined = []
    buffer = ""
    for line in lines:
        # если строка начинается с R/F, добавляем к предыдущей
        if re.match(r"^R/?F[:：]", line, re.IGNORECASE):
            buffer += " " + line
        # если строка начинается с FOB — новая запись
        elif re.match(r"^FOB", line, re.IGNORECASE):
            if buffer:
                combined.append(buffer.strip())
            buffer = line
        else:
            # если просто дополнительная строка (редкий случай)
            buffer += " " + line
    if buffer:
        combined.append(buffer.strip())

    for block in combined:
        # Извлекаем части маршрута: FOB ... - station - border - destination
        match_route = re.search(
            r"FOB\s+([^-]+)-\s*([^-]+station)\s*-\s*([^-]+border)\s*-\s*([\w\s()]+)",
            block,
            re.IGNORECASE
        )
        if not match_route:
            continue
        pol_raw, station, border, dest = [x.strip(" -") for x in match_route.groups()]

        # Извлекаем R/F часть
        match_rf = re.search(r"R/?F[:：]\s*USD\s*([\d,./]+)\s*/?\s*([^\s]+)?", block, re.IGNORECASE)
        cost = match_rf.group(1).replace(",", "").replace("/40",'').strip() if match_rf else ""
        container_type = "40HQ"
        if match_rf and match_rf.group(2):
            container_type = "40HQ" if "40" in match_rf.group(1) else "20GP"

        # Извлекаем ETD и Cut off
        etd = re.search(r"ETD[:：]?\s*([A-Za-z0-9/.\-]+)", block)
        etd_val = etd.group(1) if etd else ""

        cutoff = re.search(r"Cut[ -]?off[:：]?\s*([A-Za-z0-9/.\-]+)", block)
        cutoff_val = cutoff.group(1) if cutoff else ""

        # Извлекаем спец. пометки
        note = ""
        if "(" in block:
            note_match = re.search(r"\(([^)]+)\)", block)
            if note_match:
                note = note_match.group(1)

        # Разбиваем POL на города
        pol_list = re.split(r"[/,]", pol_raw)
        dest_port = dest.split()[0].strip()

        for pol in pol_list:
            pol = pol.strip()
            if not pol:
                continue

            pol_port = port_dict.get(pol.title(), pol.title())
            pod_port = region_dict.get(dest_port.title(), dest_port.title())
            start_country = get_country(pol_port)
            end_country = get_country(pod_port)
            record = {
                "transport_type": "rail",
                "start_point": f"{pol_port}, {start_country}",
                "end_point": f"{pod_port}, {end_country}",
                "final_destination": f"All, {end_country}",
                "container_type": container_type,
                "weight_limit": container_size_dict.get(container_type, ""),
                "cost": cost,
                "currency": currency_dict.get("$", "USD"),
                "departure_dates": {etd_val} if etd_val else {},
                "company": "Shenzhen Wotu International",
                "customs": "",
                "conditions": (
                    f"Станция: {station}\n"
                    f"Граница: {border}\n"
                    f"Cut-off: {cutoff_val}\n"
                    f"Примечание: {note}"
                    f"FOB, COC, {note or ''}".strip(", ")
                )
            }
            results.append(record)

    return pd.DataFrame(results)

# =============================
# 20. Парсер Moro Logistics
# =============================
def normalize(v):
    return re.sub(r'[\n\r"]+', ' ', str(v)).strip() if v not in [None, "None", ''] else ""

def parse_MoroLogistics(pdf_tables: list, company_name="Moro Logistics"):
    results = []
    container_type_list = {
        "SOC": ['20GP', '40HQ', '20RF', '40RF'],
        "COC": ['20GP', '40HQ', '40RF']
    }
    table2=False
    for idx, df in enumerate(pdf_tables, 1):
        df = df.fillna("")
        rows = df.values.tolist()
        if not rows:
            continue

        # ищем строку с заголовками (содержит POL и POD)
        header_row_idx = None
        for i, row in enumerate(rows):
            row_ = [v for v in row if v!='' ]
            joined = " ".join(map(str, row_))
            if "POL" in joined and "POD" in joined:
                header_row_idx = i
                break
        if header_row_idx is None:
            print(f"⚠️ Таблица {idx}: не найдена строка с заголовками")
            continue

        headers_ = [normalize(c) for c in rows[header_row_idx] if normalize(c)]
        if len(headers_) < 3:
            print(f"⚠️ Таблица {idx}: мало колонок после очистки")
            continue
        headers = []
        for header in headers_:
            if header == "SOC" or header == "COC":
                for conteiner_type in container_type_list[header]:
                    headers.append(f"{header}_{conteiner_type}")
            else:
                headers.append(header)
        # данные ниже строки с заголовками
        #print(headers)
        data_rows = []
        CTSP = False
        NLE = False
        for r in rows[header_row_idx + 1:]:
            #print("R = ",r)
            clean = []
            if "SPB CTSP" in r:
                CTSP = True
            elif "Novorossiysk(NLE)" in r:
                NLE = True
            clean = [normalize(x) for x in r]
            if CTSP and not NLE:
                cleanV1 = clean[:3]
                #print(clean,cleanV1)
                for x in range(3, len(clean)):
                    if clean[x] not in [None, "None", '']:
                        cleanV1.append(clean[x])
                clean = cleanV1
            elif NLE:
                cleanV1 = clean[:2]
                #print(clean,cleanV1)
                cleanV1.append(clean[3])
                for x in range(4, len(clean)):
                    if clean[x] not in [None, "None", '']:
                        cleanV1.append(clean[x])
                clean = cleanV1
            #print(clean)
            if clean[0] == '':
                continue
            # выравниваем по длине заголовков
            if len(clean) < len(headers):
                clean += [""] * (len(headers) - len(clean))
            elif len(clean) > len(headers):
                clean = clean[:len(headers)]
            data_rows.append(clean)
        df_clean = pd.DataFrame(data_rows, columns=headers)
        df_clean = df_clean.replace("None", "").fillna("")
        #print(df_clean)
        # если столбцы названы странно — переименуем
        rename_map = {}
        for c in df_clean.columns:
            lc = c.lower()
            if "etd" in lc:
                rename_map[c] = "ETD"
            elif "pol" in lc:
                rename_map[c] = "POL"
            elif "pod" in lc:
                rename_map[c] = "POD"
            elif "carrier" in lc:
                rename_map[c] = "Carrier"
            elif "remark" in lc:
                rename_map[c] = "Remarks"
            elif "direct" in lc:
                rename_map[c] = "Direct"
            elif "free" in lc:
                rename_map[c] = "Free Time"
        df_clean.rename(columns=rename_map, inplace=True)

        # заполняем пустые значения POD и Carrier вниз
        for col in ["POD", "Carrier"]:
            if col in df_clean.columns:
                df_clean[col] = df_clean[col].replace("", pd.NA).ffill()
        
        # основной парсинг
        for _, row in df_clean.iterrows():
            #row = v for v in row_ if v!='' 
            pol = row.get("POL", "")
            pod = row.get("POD", "")
            carrier = row.get("Carrier", "")
            etd = row.get("ETD", "")
            remarks = row.get("Remarks", "")
            direct = row.get("Direct", "")
            free_time = row.get("Free Time", "")
            if pol == "POL":
                table2=True
                continue

            # собираем тарифы
            for soc_coc in container_type_list.keys():
                cont_types = container_type_list[soc_coc]
                for cont_type in cont_types:
                    soc_coc_=soc_coc
                    cont = f"{soc_coc}_{cont_type}"
                    if cont not in df_clean.columns:
                        continue
                    
                    cost_raw = str(row.get(cont, "")).strip()
                    if not cost_raw or cost_raw in ["/", "-", "—"]:
                        continue
                    try:
                        cost = int(cost_raw)
                    except Exception as e:
                        continue

                    for p in re.split(r"[,/]", pol):
                        p = p.strip()
                        if not p:
                            continue

                        pol_port = port_dict.get(p.title(), p.title())
                        pod_port = region_dict.get(pod.title(), pod.title())
                        start_country = get_country(pol_port)
                        end_country = get_country(pod_port)

                        if table2 and cont in ["SOC_40HQ", "SOC_20GP"]:
                            etd = row.get("SOC_20RF", "")
                            direct = row.get("SOC_40RF", "")
                            free_time = row.get("COC_20GP", "")
                            soc_coc_ = "COC"
                        elif table2:
                            continue
                        results.append({
                            "transport_type": "sea",
                            "start_point": f"{pol_port}, {start_country}",
                            "end_point": f"{pod_port}, {end_country}",
                            "final_destination": f"All, {end_country}",
                            "container_type": cont_type,
                            "weight_limit": container_size_dict.get(cont_type, ""),
                            "cost": cost,
                            "currency": currency_dict.get("$", "USD"),
                            "departure_dates": [etd] if etd else [],
                            "company": company_name,
                            "customs": (
                                f"Перевозчик: {carrier}\n"
                                f"Свободное время: {free_time}\n"
                                f"Маршрут: {direct}\n"
                                f"ETD: {etd}\n"
                                f"Примечания: {remarks}"
                            ),
                            "conditions": f"{soc_coc_}. {pod}"
                        })

    return pd.DataFrame(results)

def get_tables_pdf_MoroLogistics(url, path, company):
    pdf_path = Path(path)

    tables_data = []
    table_str = list()
    len_page = 0
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            len_page += 1
            for table in page.extract_tables():
                table_str += table
            text = page.extract_text()
            if text:
                text_list = text.split('\n')
                for line in text_list:
                    if len_page >= 3:
                        split_ = line.split()
                        if len(split_) >= 4:
                            try:
                                gp20 = int(split_[1])
                                hq40 = int(split_[2])
                                table_str += [[split_[0], None, None, None, None, split_[1], None, None, split_[2], None, split_[3], None, None, None, None, None, None, None, None]]
                            except Exception as e:
                                continue
        df = pd.DataFrame(table_str)
        tables_data.append(df)

    # Сохранение таблиц
    for i, df in enumerate(tables_data, 1):
        df.to_csv(f"tablets/table_{i}_{company}.csv", index=False)
    
    return tables_data

# =============================
# 21. Парсер Transforever International Forwarding
# =============================
def clean(v):
    if v is None:
        return ""
    return str(v).replace("\n", " ").strip()

def split_etd(etd):
    """
    Превращает значения типа:
    '19/26.Aug'  → ['19.Aug', '26.Aug']
    '14/17/20.Aug' → ['14.Aug','17.Aug','20.Aug']
    """
    etd = etd.strip()
    if not etd:
        return []
    month = ""
    if "." in etd:
        month = etd.split(".")[-1]
    dates = etd.replace("." + month, "")
    parts = dates.split("/")
    return [f"{p}.{month}" for p in parts]

def parse_Transforever_International_Forwarding(file_path: str, company_name="Transforever International Forwarding"):
    df = pd.read_excel(file_path, sheet_name = "Transforever International Forw")
    # Нормализация колонок
    df.columns = [clean(c) for c in df.columns]

    # ffill загрузочного города
    df["Loading place"] = df["Loading place"].replace("", pd.NA).ffill().fillna("")

    results = []

    for _, row in df.iterrows():
        loading_place = clean(row["Loading place"])
        pol = clean(row["POL Station"])
        border = clean(row["Border"])
        pod_station = clean(row["POD Station"])
        etd_raw = clean(row["ETD"])
        ttdays = clean(row["TT/days"])
        fob = clean(row["FOB COC"])
        exw = clean(row["EXW COC"])
        note = clean(row["Note"]) or ""

        # пропускаем пустые строки
        if not pol or not pod_station:
            continue

        # разбор ETD — может быть несколько дат
        etd_list = split_etd(etd_raw)
        cost_list = []
        # ставка (FOB)
        if fob and fob.isdigit():
            cost_list.append(fob)
        if exw and exw.isdigit():
            cost_list.append(exw)


        # определение стран и переводов
        start_city = pol.split("/")[0].strip()
        start_point = port_dict.get(start_city.title(), start_city.title())
        end_city_list = pod_station.split("/")
        

        start_country = get_country(start_point)
        

        # каждая дата → отдельная запись
        etd_final = etd_list if etd_list else [etd_raw]

        #for etd in etd_final:
        for cost in range(len(cost_list)):
            for end_city in end_city_list:
                end_point = region_dict.get(end_city.title(), end_city.title())
                if end_point == end_city.title() and len(end_city.split(" ", 1)) >= 2:
                    end_point = region_dict.get(end_city.split(" ", 1)[1].title(), end_city.split(" ", 1)[1].title())
                end_country = get_country(end_point)
                record = {
                    "transport_type": "rail",
                    "start_point": f"{start_point}, {start_country}",
                    "end_point": f"{end_point}, {end_country}",
                    "final_destination": f"All, {end_country}",
                    "container_type": "40HQ",
                    "weight_limit": container_size_dict.get("40HQ", "40HQ"),
                    "cost": cost_list[cost],
                    "currency": "USD",
                    "departure_dates": etd_final,
                    "company": company_name,
                    "customs": (
                        f"Loading place: {loading_place}\n"
                        f"Border: {border}\n"
                        f"Transit time: {ttdays}\n"
                        f"Note: {note}"
                        f"POD Station: {pod_station}"
                    ),
                    "conditions": "FOB COC" if cost == 0 else "EXW COC"
                }

                results.append(record)
    return pd.DataFrame(results)

# =============================
# 22. Парсер Shaanxi Coal International Logistics
# =============================
def parse_Shaanxi_Coal_International_Logistics(file_path: str, company_name="Shaanxi Coal International Logistics"):
    df = pd.read_excel(file_path, sheet_name = "Shaanxi Coal International Logi")
    df = df.fillna("")
    df.columns = [clean(c) for c in df.columns]

    results = []
    cargo_type_old = ''
    for _, row in df.iterrows():
        dep_raw = clean(row.get("Departure Station", ""))
        border = clean(row.get("Border", ""))
        destination = clean(row.get("Destination", ""))
        rate_raw = clean(row.get("Rate (40HQ)", ""))
        cargo_type = clean(row.get("Cargoes", ""))
        if cargo_type:
            cargo_type_old = cargo_type
        if not dep_raw or not destination or not rate_raw:
            continue

        # -----------------------------
        # 1. POL (из строки типа "FOB Shanghai" или "FOB Shenzhen/Dongguan")
        # -----------------------------
        pol_match = re.findall(r"FOB\s+(.+)", dep_raw, flags=re.I)
        if not pol_match:
            continue
        pol_full = pol_match[0].strip()+"/"

        # -----------------------------
        # 2. Border — может быть "Erlian/Alashankou"
        # -----------------------------
        borders = [b.strip() for b in border.split("/") if b.strip()]

        # -----------------------------
        # 3. Destination — Electrougli, Moscow, etc.
        # -----------------------------
        pod_city = destination.split("/")[0].strip()

        # -----------------------------
        # 4. Cost
        # -----------------------------
        cost = re.sub(r"[^\d]", "", rate_raw)
        if not cost:
            continue

        # -----------------------------
        # 5. Перевод городов и стран
        # -----------------------------
        for pol_city_ in pol_full.split("/"):
            if pol_city_ == '':
                continue
            for border in borders:
                pol_city = pol_city_.strip()
                pol_port = port_dict.get(pol_city.title(), pol_city.title())
                pod_port = region_dict.get(pod_city.title(), pod_city.title())

                start_country = get_country(pol_port)
                end_country = get_country(pod_port)

                # -----------------------------
                # 6. Создание записи
                # -----------------------------
                record = {
                    "transport_type": "rail",
                    "start_point": f"{pol_port}, {start_country}",
                    "end_point": f"{pod_port}, {end_country}",
                    "final_destination": f"All, {end_country}",

                    "container_type": "40HQ",
                    "weight_limit": container_size_dict.get("40HQ", ""),

                    "cost": cost,
                    "currency": currency_dict.get("$", "USD"),

                    "departure_dates": [],  # в таблице нет ETD → пусто
                    "company": company_name,

                    "customs": (
                        f"Departure station: FOB {pol_city}\n"
                        f"Border(s): {border}\n"
                        f"Cargo: {cargo_type_old}"
                    ),

                    "conditions": "FOB"
                }

                results.append(record)

    return pd.DataFrame(results)

# =============================
# 23. Парсер Неизвестная_компания_4
# =============================
def parse_UnknownCompany4(file_path: str, company_name="Неизвестная_компания_4"):
    df = pd.read_excel(file_path, sheet_name = company_name)
    results = []
    df = df.fillna("")

    # Вся вторая ячейка — многострочный текст
    full_text = ""
    for row in df.values:
        for cell in row:
            cell = clean(cell)
            if cell and ("FOB" in cell or "R/F" in cell):
                full_text += "\n" + cell

    if not full_text.strip():
        print("⚠ Нет данных FOB/RF — таблица пуста")
        return pd.DataFrame()

    # Разделяем записи по FOB-блокам
    blocks = re.split(r'(?=FOB )', full_text)
    blocks = [b.strip() for b in blocks if b.strip()]

    for block in blocks:

        # -----------------------------
        # 1. POL список (FOB Shanghai/Wuxi/Suzhou...)
        # -----------------------------
        m_pol = re.search(r"FOB\s+([A-Za-z0-9' /.-]+?)\s+-", block)
        if not m_pol:
            continue
        pol_list_raw = m_pol.group(1)
        pol_cities = [p.strip() for p in pol_list_raw.split("/")]

        # -----------------------------
        # 2. Departure station
        # -----------------------------
        m_dep = re.search(r"-\s*([A-Za-z0-9' ]+?) station", block)
        departure_station = clean(m_dep.group(1) if m_dep else "")

        # -----------------------------
        # 3. Border
        # -----------------------------
        m_border = re.search(r"station\s*-\s*([A-Za-z0-9' /]+?)\s*-\s*", block)
        border = clean(m_border.group(1) if m_border else "")

        # -----------------------------
        # 4. POD (последняя часть)
        # -----------------------------
        m_pod = re.search(r"-\s*([A-Za-z0-9' ]+?)\s*(?:\n|R/F:|$)", block)
        pod_city = clean(m_pod.group(1) if m_pod else "")

        # -----------------------------
        # 5. COST
        # могут быть варианты:
        # USD4050/40'HQ
        # USD5000/5100/5000/5000 --- 40'HQ
        # -----------------------------
        m_cost = re.search(r"R/F:\s*USD\s*([\d/]+)", block, re.I)
        if m_cost:
            rate_values = m_cost.group(1).split("/")
            cost = re.sub(r"[^\d]", "", rate_values[0])
        else:
            cost = ""

        # -----------------------------
        # 6. Container type (40HQ)
        # -----------------------------
        m_ct = re.search(r"(40'?HQ)", block, re.I)
        container_type = m_ct.group(1).upper().replace("'", "") if m_ct else "40HQ"

        # -----------------------------
        # 7. ETD
        # -----------------------------
        m_etd = re.search(r"ETD:\s*([0-9A-Za-z/.-]+)", block)
        etd = clean(m_etd.group(1) if m_etd else "")

        # -----------------------------
        # 8. CUT OFF
        # -----------------------------
        m_cut = re.search(r"Cut ?off:\s*(.+?)(?:$|\s{2,})", block, re.I)
        cutoff = clean(m_cut.group(1).split('"')[0] if m_cut else "")

        # -----------------------------
        # 9. Генерация записей для каждого POL
        # -----------------------------
        for pol in pol_cities:

            pol_port = port_dict.get(pol.title(), pol.title())
            pod_port = region_dict.get(pod_city.title(), pod_city)

            start_country = get_country(pol_port)
            end_country = get_country(pod_port)

            record = {
                "transport_type": "rail",
                "start_point": f"{pol_port}, {start_country}",
                "end_point": f"{pod_port}, {end_country}",
                "final_destination": f"All, {end_country}",

                "container_type": container_type,
                "weight_limit": container_size_dict.get(container_type, ""),

                "cost": cost,
                "currency": currency_dict.get("$", "USD"),

                "departure_dates": [etd] if etd else [],
                "company": company_name,

                "customs": (
                    f"Departure station: {departure_station}\n"
                    f"Border: {border}\n"
                    f"Cut-off: {cutoff}\n"
                ),

                "conditions": "FOB COC"
            }

            results.append(record)

    return pd.DataFrame(results)

# =============================
# 24. Парсер Неизвестная_компания_3
# =============================
def parse_UnknownCompany3(file_path: str, company_name="Неизвестная_компания_3"):
    df = pd.read_excel(file_path, sheet_name = company_name)
    results = []
    df = df.fillna("")

    # ============================================
    # 1. Собрать весь текст в одну строку
    # ============================================
    full_text = ""
    for row in df.values:
        for cell in row:
            #cell = clean(cell)
            if cell:
                full_text += '\n' + cell

    if not full_text.strip():
        return pd.DataFrame()

    # ============================================
    # 2. Разбить на смысловые блоки
    # блоки отделяются кавычками
    # ============================================
    blocks = full_text.split('\n') #re.split(r'"', full_text)
    blocks = [b.strip() for b in blocks if b.strip()]
    # ============================================
    # 3. Вспомогательная функция
    # ============================================
    def add_record(pol, pod, border, etd, cost, container, mode, customs):
        pol_port = port_dict.get(pol.title(), pol)
        pod_port = region_dict.get(pod.title(), pod)

        start_country = get_country(pol_port)
        end_country = get_country(pod_port)

        return {
            "transport_type": mode,
            "start_point": f"{pol_port}, {start_country}",
            "end_point": f"{pod_port}, {end_country}",
            "final_destination": f"All, {end_country}",

            "container_type": container,
            "weight_limit": container_size_dict.get(container, ""),

            "cost": cost,
            "currency": "USD",

            "departure_dates": etd if etd else [],
            "company": company_name,

            "customs": customs,
            "conditions": ""
        }

    # ============================================
    # 4. Парсим каждый блок
    # ============================================
    for block in blocks:
        text = block.strip()

        # ----------------------------------------
        # 🔵 TRAIN LINES
        # ----------------------------------------
        if "train" in text.lower():

            # Пример блока:
            # 'Tianjin train-- Erlianu border--Bely rast ETD:8.14/8.21 FOB Tianjin USD3850/40HC;'

            # 1. Выделяем начало маршрута
            m = re.search(
                r"(\w+)\s*train.*?--\s*([\w/]+)\s*border?\s*--\s*([\w ]+)",
                text,
                re.I
            )
            if not m:
                continue

            dep_city = m.group(1)
            border = m.group(2)
            pod = m.group(3).replace("ETD","").strip()

            # 2. ETD — может быть несколько дат
            etd_match = re.search(r"ETD[: ]*([0-9./A-Za-z]+)", text)
            etd = etd_match.group(1).split("/") if etd_match else []

            # 3. FOB указания (их может быть много)
            # пример:
            # FOB Tianjin USD3850/40HC
            # FOB Guangzhou/Shenzhen USD4350/40HC
            fobs = re.finditer(
                r"FOB\s+.*",
                text,
                re.I
            )
            
            for f in fobs:
                container = "40HC" if "40HC" in f.group(0) else ""
                fo_fobs = f.group(0).split(";")
                for fo_fob in fo_fobs:
                    if fo_fob:
                        fo_ = fo_fob.split()
                        pol_list = fo_[1].split("/")
                        cost = fo_[2].split("/")[0] if "/" in fo_[2] else fo_[2]

                        for pol in pol_list:
                            results.append(add_record(
                                pol=pol,
                                pod=pod,
                                border=border,
                                etd=etd,
                                cost=cost.replace("USD", ""),
                                container=container,
                                mode="rail",
                                customs=text
                            ))

        # ----------------------------------------
        # 🔵 TRUCK LINES (обычный автотранспорт)
        # ----------------------------------------
        if "/Truck" in text:
            continue
            # Пример:
            # FOB Qingdao/Tianjin/Cangzhou to Moscow USD9500/Truck

            fobs = re.finditer(
                r"FOB\s+([A-Za-z/]+)\s+to\s+([A-Za-z ]+)\s+USD(\d+)/Truck",
                text
            )
            for f in fobs:
                pol_list = f.group(1).split("/")
                pod = f.group(2)
                cost = f.group(3)

                for pol in pol_list:
                    results.append(add_record(
                        pol=pol,
                        pod=pod,
                        border="Truck",
                        etd="",
                        cost=cost,
                        container="TRUCK",
                        mode="truck",
                        customs=text
                    ))

        # ----------------------------------------
        # 🔵 SEA (море)
        # ----------------------------------------
        if "SEA" in text.upper():

            # Пример строки:
            # FOB China main port - St Peterburg by SEA USD3800-4550/20GP ...

            m = re.search(
                r"FOB\s+China.*?St\s*peterburg.*?USD([\d-]+)/20GP.*?USD([\d-]+)/40HQ.*?ETD[: ]*([0-9.\-A-Za-z/]+)",
                text,
                re.I
            )
            if m:
                cost20 = m.group(1).split("-")[0]
                cost40 = m.group(2).split("-")[0]
                etd = m.group(3)

                results.append(add_record(
                    pol="China main port",
                    pod="St Petersburg",
                    border="Sea",
                    etd=etd,
                    cost=cost20,
                    container="20GP",
                    mode="sea",
                    customs=text
                ))
                results.append(add_record(
                    pol="China main port",
                    pod="St Petersburg",
                    border="Sea",
                    etd=etd,
                    cost=cost40,
                    container="40HQ",
                    mode="sea",
                    customs=text
                ))

        # ----------------------------------------
        # 🔵 TIR SERVICE (FTL)
        # ----------------------------------------
        if "FTL" in text.upper() or "TIR SERVICE" in text.upper():
            continue
            # Пример:
            # MOSCOW --MANZHOULIA--TIANJIN USD4950/FTL

            ftl_matches = re.finditer(
                r"MOSCOW\s*--\s*MANZHOULIA\s*--\s*([A-Za-z/]+)\s*USD(\d+)/FTL",
                text,
                re.I
            )
            for f in ftl_matches:
                pod = f.group(1)
                cost = f.group(2)

                results.append(add_record(
                    pol="Moscow",
                    pod=pod,
                    border="Manzhouli",
                    etd="",
                    cost=cost,
                    container="FTL",
                    mode="tir",
                    customs=text
                ))

    return pd.DataFrame(results)

# =============================
# 25. Парсер Неизвестная_компания_2
# =============================
def parse_UnknownCompany2(filepath:str):
    company="Неизвестная_компания_2"
    tables, text_blocks = get_tables_pdf(None, filepath, company)
    text = "\n".join(text_blocks)

    # --- 1. Найти блок маршрута ---
    route_match = re.search(r"Route:\s*(.+?)\s*ETD:", text, re.I | re.S)
    if not route_match:
        return pd.DataFrame([])

    route = route_match.group(1).strip()

    # Нормализация разделителей
    # Chongqing – Manzhouli – Shushary → ['Chongqing','Manzhouli','Shushary']
    route_points = re.split(r"\s*[–-]\s*", route)
    start_point = route_points[0]
    end_point = route_points[-1]

    # --- 2. Найти ETD ---
    etd_match = re.search(r"ETD:\s*([A-Za-z]+\s*\d+)", text)
    etd = etd_match.group(1).strip() if etd_match else ""

    # --- 3. Найти блок цен ---
    # Город: 3300 USD/40HQ
    rate_pattern = re.compile(
        r"([A-Za-z]+)\s*:\s*(\d+)\s*USD\s*/\s*(\d+\w+)",
        re.I
    )

    results = []

    for city, price, container_type in rate_pattern.findall(text):
        pol_port = port_dict.get(city.title(), city)
        pod_port = region_dict.get(end_point.title(), end_point)
        results.append({
            "transport_type": "rail",
            "start_point": f"{pol_port}, {get_country(pol_port)}",
            "end_point": f"{pod_port}, {get_country(pod_port)}",

            "final_destination": f"All, {get_country(pod_port)}",

            "container_type": container_type,
            "weight_limit": container_size_dict.get(container_type, ""),

            "cost": price,
            "currency": "USD",

            "departure_dates": etd if etd else [],

            "company": company,

            "customs": f"Route: {route}\nPOD: {pod_port}",
            "conditions": "All-in Rate"
        })

    return pd.DataFrame(results)

# =============================
# 26. Парсер Khasan
# =============================
def parse_Khasan(filepath: str):
    company = "KHASAN"
    tables, text_blocks = get_tables_pdf(None, filepath, company)
    data_scvoznoi = []
    text_all = "\n".join(text_blocks)
    # нормализация пробелов и переводов строк
    text = text_all.replace("\r", "\n")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]

    # ==============================
    # ПАРСИНГ МОРСКОЙ СТАРТУЮЩИХ ИЗ ПОРТА
    # ==============================

    # regex: берём любую текстовую часть до первых чисел (цены)
    line_re = re.compile(r"^(?P<pol>.+?)\s+(?P<dc>\d{3,5})\s*\$?\s+(?P<hc>\d{3,5})\s*\$?$")
    # также вариант где числа и $ могут быть слиты, или присутствует /40HQ, и т.п.
    line_re2 = re.compile(r"^(?P<pol>.+?)\s+(?P<dc>\d{3,5})\s*\$?\s*/?\s*(?P<hc>\d{3,5})\s*\$?$")

    results = []
    pod = "Владивосток" if "ВМПП/SOLLERS" in text else ""
    shenzhen_20 = shenzhen_40 = None

    for ln in lines:
        # пробуем найти пар (поле цены) в строке (строго построчно)
        m = line_re.match(ln) or line_re2.match(ln)
        if m:
            pol = m.group("pol").strip()
            dc = int(m.group("dc"))
            hc = int(m.group("hc"))

            # нормализуем пол: если в конце есть запятая/точка — убрать
            pol = pol.strip(" ,;.-")

            # запомним цену Shenzhen для подстановки в дальнейшем
            if pol.lower().startswith("shenzhen"):
                shenzhen_20, shenzhen_40 = dc, hc

            results.append({"pol": pol, "pod": pod, "20DC": dc, "40HC": hc})
            continue

    # Подставляем цены Shenzhen для GUANGZHOU и XIAMEN при отсутствии собственных цен
    # (ищем в тексте слова GUANGZHOU и XIAMEN, если их нет в results как с ценой)
    pols_present = {r["pol"].lower() for r in results}
    for need in ("Guangzhou", "XIAMEN"):
        if need.lower() not in pols_present and shenzhen_20 is not None:
            results.append({"pol": need, "pod": pod, "20DC": shenzhen_20, "40HC": shenzhen_40})

    # Также дополнительно: если есть строка "NINGBO / SHANGHAI 1500 $ 2400 $"
    # наша регекспы это поймают, т.к. пол — любая текстовая часть до числа.
    # Но нам может понадобиться разделить "NINGBO / SHANGHAI" на два пол-адреса.
    expanded = []
    for rec in results:
        pol = rec["pol"]
        if "/" in pol:
            parts = [p.strip() for p in pol.split("/") if p.strip()]
            for p in parts:
                expanded.append({"pol": p, "pod": rec["pod"], "20DC": rec["20DC"], "40HC": rec["40HC"]})
        else:
            expanded.append(rec)

    # Ищем общий транзитный срок: "Общий Транзитный срок доставки ~37 дней."
    td = None
    mtd = re.search(r"Общий\s+Транзитный\s+срок\s+доставки[^0-9]*(\d{1,3})\s*д", text, re.I)
    if mtd:
        try:
            td = int(mtd.group(1))
        except:
            td = None
    for sea_rate in expanded:
        pol = sea_rate["pol"].title()
        pod = sea_rate["pod"].title()
        pol_port = port_dict.get(pol, pol)
        pod_port = region_dict.get(pod, pod)
        
        start_country = get_country(pol_port)
        end_country = get_country(pod_port)
        for i in sea_rate.keys():
            if i not in ["pol", "pod"]:
                container_type = i
                cost = sea_rate[i]
                data_scvoznoi.append({
                    "transport_type": "sea",
                    "start_point": f"{pol_port}, {start_country}",
                    "end_point": f"{pod_port}, {end_country}",
                    "final_destination": f"All, {end_country}",
                    "container_type": container_type,
                    "weight_limit": container_size_dict.get(container_type, ""),
                    "cost": cost,
                    "currency": currency_dict.get("$", "USD"),
                    "departure_dates": [],
                    "company": company,
                    "customs": f"Общий Транзитный срок доставки: {td}",
                    "conditions": "FILO COC"
                })
    # ==============================
    # ПАРСИНГ ЖД СТАРТУЮЩИХ ИЗ ПОРТА
    # ==============================
    data_rail = []
    rails = []
    pattern = re.compile(
        r"^(?P<pol>[A-Za-zА-Яа-я/]+)\s+"
        r"(?P<city>[A-Za-zА-Яа-яёЁ\-]+)\s+"
        r"(?P<r1>\d[\d\s]*)\s*₽\s+"
        r"(?P<r2>\d[\d\s]*)\s*₽\s+"
        r"(?P<r3>\d[\d\s]*)\s*₽$"
    )

    for ln in lines:
        ln = ln.strip()
        m = pattern.match(ln)
        if not m:
            continue

        r1 = int(m.group("r1").replace(" ", ""))
        r2 = int(m.group("r2").replace(" ", ""))
        r3 = int(m.group("r3").replace(" ", ""))

        rails.append({
            "pol": m.group("pol"),
            "pod": m.group("city"),
            "20DC": r1,
            "20DC_28": r2,
            "40HC": r3
        })
    
    for rail_rate in rails:
        #pol = rail_rate["pol"].title()
        pol = "Владивосток" if "ВМПП/SOLLERS" in rail_rate["pol"] else rail_rate["pol"].title()
        pod = rail_rate["pod"].title()
        pol_port = port_dict.get(pol, pol)
        pod_port = get_city_station(pod)
        
        start_country = get_country(pol_port)
        end_country = get_country(pod_port)
        for i in rail_rate.keys():
            if i not in ["pol", "pod"]:
                container_type = i
                cost = rail_rate[i]
                data_rail.append({
                    "transport_type": "rail",
                    "start_point": f"{pol_port}, {start_country}",
                    "end_point": f"{pod_port}, {end_country}",
                    "final_destination": f"All, {end_country}",
                    "container_type": "20DC" if "20DC_28" == container_type else container_type,
                    "weight_limit": container_size_dict.get(container_type, ""),
                    "cost": cost,
                    "currency": currency_dict.get("руб", "RUB"),
                    "departure_dates": [],
                    "company": company,
                    "customs": "",
                    "conditions": ""
                })
    scvoznoi = pd.DataFrame(data_scvoznoi)
    rail = pd.DataFrame(data_rail)
    return pd.concat([scvoznoi, rail], ignore_index=True) 

# =============================
# 27. Парсер SHENZHEN INTERRAIL LOGISTICS
# =============================
def parse_SHENZHEN_INTERRAIL_LOGISTICS(filepath: str):
    company = "SHENZHEN INTERRAIL LOGISTICS"
    pattern = r'''
        ^                           # Начало строки
        ([\w/]+)                 # Loading place (FOB) — может быть с / (например, Guangzhou/Shenzhen)
        \s+                       # Пробелы
        ([\w]+)                   # Departure station
        \s+                     # Пробелы
        ([\w\s]+)               # Via — может включать пробелы (например, Qisumu Manzhouli)
        \s+                     # Пробелы
        \$([\d,]+?)             # Moscow (стоимость без $)
        \s+                     # Пробелы
        (\d{1,2}-[A-Za-z]{3}|Mid-[A-Za-z]+|\w+-[A-Za-z]+)  # ETD — дата или словесное обозначение
        $                       # Конец строки
    '''

    # Компилируем с флагом re.VERBOSE (чтобы можно было комментировать)
    regex = re.compile(pattern, re.VERBOSE)
    tables, text_blocks = get_tables_pdf(None, filepath, company)
    text_all = "\n".join(text_blocks)
    text = text_all.replace("\r", "\n")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    data_rail = []
    
    for line in lines:
        if not line:
            continue
        
        match = regex.match(line)
        if match:
            loading_place = match.group(1) + "/"
            departure_station = match.group(2)
            via = match.group(3).strip()
            moscow_price = int(match.group(4).replace(',', ''))  # Убираем запятые и в int
            etd = match.group(5)
            for pol in loading_place.split("/"):
                if not pol:
                    continue
                pol_port = port_dict.get(pol, pol)
                pod_port = region_dict.get("Moscow","Moscow")
                border_point = border_dict.get(via, via)
                container_type = "40HQ"
                start_country = get_country(pol_port)
                end_country = get_country(pod_port)
                data_rail.append({
                    "transport_type": "rail",
                    "start_point": f"{pol_port}, {start_country}",
                    "end_point": f"{pod_port}, {end_country}",
                    "final_destination": f"All, {end_country}",
                    "container_type": container_type,
                    "weight_limit": container_size_dict.get(container_type, ""),
                    "cost": moscow_price,
                    "currency": currency_dict.get("$", "USD"),
                    "departure_dates": etd,
                    "company": company,
                    "customs": "",
                    "conditions": "COC",
                    "border_point": border_point
                })
    
    return pd.DataFrame(data_rail)

# =============================
# 28. Парсер Shenzhen Wotu International Logistics
# =============================
def parse_Shenzhen_Wotu_International_Logistics(filepath: str):
    """
    Парсит текст с предложениями по перевозке грузов и возвращает список словарей с полями:
    - origin: точка отправления
    - destination: точка прибытия
    - price: цена
    - currency: валюта (обычно USD)
    - terms: условия (например, 40'HQ COC)
    - route: маршрут (через какие станции/границы)
    - timestamp: дата и время, если указаны
    """
    company = "Shenzhen Wotu International Logistics"
    tables, text_blocks = get_tables_pdf(None, filepath, company)
    text_all = "\n".join(text_blocks)
    text = text_all.replace("\r", "\n")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    data_rail = []

    fob_pattern = re.compile(
        r'^FOB\s+(.+?)\s*-\s*(.+?)\s*-\s*([\w\s]+?)\s+([40\'[A-Z]+\s+(?:COC|SOC))',
        re.IGNORECASE
    )

    # Шаблон для цены: ищем USD<число> или USD<пробел><число>
    price_pattern = re.compile(r'USD\s*(\d+)', re.IGNORECASE)

    current_route = None
    current_destination = None
    current_terms = None
    timestamp = None
    border_part = None
    currency = ""
    container_type = "40HQ"
    for line in lines:
        # Ищем маршрут FOB ... – ... – ...
        route_match = fob_pattern.search(line)
        if route_match:
            origin_part = route_match.group(1).strip()
            middle_part = route_match.group(2).strip()
            destination_part = route_match.group(3).strip()
            border_part = middle_part
            current_route = f"{origin_part} – {middle_part} – {destination_part}"
            current_destination = destination_part
            current_terms = None  # сбрасываем, т.к. может быть новый terms
            continue

        # Ищем цены
        price_match = price_pattern.search(line)
        if price_match:
            
            if "USD" in price_match.group(0):
                currency = "USD"
            else:
                currency = "руб"
            price_str = price_match.group(1)
            
            city_part = re.sub(r'[A-Z]{3}\d+|\d+', '', line).strip()
            city_part = re.sub(r'-\s*', '', city_part).strip() + "/"
            for pol_ in city_part.split("/"):
                if pol_ and price_str:
                    pol = pol_.title()
                    pod = current_destination.title()
                    pol_port = port_dict.get(pol, pol)
                    pod_port = region_dict.get(pod, pod)
                    border_point = border_dict.get(border_part, border_part)
                    start_country = get_country(pol_port)
                    end_country = get_country(pod_port)
                    data_rail.append({
                        "transport_type": "rail",
                        "start_point": f"{pol_port}, {start_country}",
                        "end_point": f"{pod_port}, {end_country}",
                        "final_destination": f"All, {end_country}",
                        "container_type": container_type,
                        "weight_limit": container_size_dict.get(container_type, ""),
                        "cost": price_str,
                        "currency": currency_dict.get(currency, "USD"),
                        "departure_dates": [],
                        "company": company,
                        "customs": "",
                        "conditions": "COC",
                        "border_point": border_point
                    })
    return pd.DataFrame(data_rail)


# =============================
# Универсальный парсер (объединяет все)
# =============================
def parse_all():
    TransportCompanies = "Транспортные компании.xlsx"
    df_TransContainer = parse_TransContainer("data/TransContainer.xlsx") #++ кроме КП
    df_RusTrans = parse_RusTrans("data/RusTrans.xlsx")  #++ пока только с файла тарифы2.xslx
    df_MarmedContainer = parse_MarmedContainer("data/Marmed-container.xlsx") #++ кроме import ячейка в зеленом
    df_HS_CHINA_LIMITED = parse_HS_CHINA_LIMITED("data/HS_CHINA_LIMITED.xlsx")
    df_Torgmoll = parse_Torgmoll("data/Torgmoll.xlsx") #не до конца готов, только КНР-СПБ, не все переведено
    df_Mohill = parse_Mohill("data/Mohill.xlsx") # вытащить отдельно в поле про отправление. готово, кроме VVO+Railway там вопрос: это как один маршрут и его нельзя делить? 
    df_EuroSib = parse_EuroSib()
    df_GrandLog = parse_GrandLog("D:/Logiways/Ноябрь/Тарифы+ Расписание-3/37. ГрандЛог/26.11.2025/Тариф.pdf")
    df_TML = parse_TML(TransportCompanies)
    df_GW_CHINA_LIMITED = parse_GW_CHINA_LIMITED(TransportCompanies)
    df_Shenzhen_Eagleway_Supply_Chain_Management = parse_Shenzhen_Eagleway_Supply_Chain_Management(TransportCompanies)
    df_Shenzhen_Space_logistics = parse_Shenzhen_Space_logistics(TransportCompanies)
    df_LCL = parse_LCL(TransportCompanies)
    df_Amethyst = parse_Amethyst(TransportCompanies)
    df_Hesion_Global_Logistics = parse_Hesion_Global_Logistics(TransportCompanies)
    df_NingBo_YSTAR_Logistics = parse_NingBo_YSTAR_Logistics(TransportCompanies)
    df_UnknownCompany1 = parse_UnknownCompany1(TransportCompanies)
    df_Spacelog = parse_Spacelog(TransportCompanies)
    df_Shenzhen_Wotu_International = parse_Shenzhen_Wotu_International(TransportCompanies)
    tables_data_MoroLogistics = get_tables_pdf_MoroLogistics(
        "",
        "D:/Logiways/Август/Тарифы+ Расписание/24. Moro Logistics/Тариф.pdf",
        "Moro Logistics"
    )
    df_Moro_Logistics = parse_MoroLogistics(tables_data_MoroLogistics, company_name="Moro Logistics")
    df_Transforever_International_Forwarding = parse_Transforever_International_Forwarding(TransportCompanies)
    df_Shaanxi_Coal_International_Logistics = parse_Shaanxi_Coal_International_Logistics(TransportCompanies)
    df_UnknownCompany4 = parse_UnknownCompany4(TransportCompanies)
    df_UnknownCompany3 = parse_UnknownCompany3(TransportCompanies)
    df_UnknownCompany2 = parse_UnknownCompany2("D:/Logiways/Ноябрь/Тарифы+ Расписание-3/30. Неизвестная компания_2/Тариф.pdf")
    df_Khasan = parse_Khasan("D:/Logiways/Ноябрь/Тарифы+ Расписание-3/23. KHASAN/26.11.2025/Тариф + расписание.pdf")
    df_SHENZHEN_INTERRAIL_LOGISTICS = parse_SHENZHEN_INTERRAIL_LOGISTICS("D:/Logiways/Ноябрь/Тарифы+ Расписание-3/27. SHENZHEN INTERRAIL LOGISTICS/Тариф+Расписание_2.pdf")
    df_Shenzhen_Wotu_International_Logistics = parse_Shenzhen_Wotu_International_Logistics("D:/Logiways/Ноябрь/Тарифы+ Расписание-3/25. Shenzhen Wotu International Logistics/Тариф.pdf")

    return pd.concat([
        df_TransContainer, df_RusTrans, df_MarmedContainer, df_HS_CHINA_LIMITED, df_Torgmoll, 
        df_Mohill, df_EuroSib, df_GrandLog, df_TML, df_GW_CHINA_LIMITED, 
        df_Shenzhen_Eagleway_Supply_Chain_Management, df_Shenzhen_Space_logistics, df_LCL, df_Amethyst, df_Hesion_Global_Logistics, 
        df_NingBo_YSTAR_Logistics, df_UnknownCompany1, df_Spacelog, df_Shenzhen_Wotu_International, df_Moro_Logistics, 
        df_Transforever_International_Forwarding, df_Shaanxi_Coal_International_Logistics, df_UnknownCompany4, df_UnknownCompany3, df_UnknownCompany2,
        df_Khasan, df_Shenzhen_Wotu_International_Logistics
        ], ignore_index=True)


#df_all = parse_all()
# =============================
# Обогащение общих данных новыми столбцами
# =============================

def normalize_date(date_str, year=2025):
    # Удаляем лишние символы
    date_str = date_str.replace(' ', '').replace(':', '')
    
    if '.' in date_str:
        parts = date_str.split('.')
        if len(parts) == 3:  # Формат dd.mm.yyyy
            return f"{parts[2]}-{parts[1].zfill(2)}-{parts[0].zfill(2)}"
        elif len(parts) == 2:  # Формат mm.dd
            month, day = parts
            return f"{year}-{month.zfill(2)}-{day.zfill(2)}"
        else:
            return ""
    elif '-' in date_str:
        # Разбиваем дату по дефисам
        parts = date_str.split('-')
        if len(parts) == 3:  # Формат yyyy-mm-dd
            return f"{parts[0]}-{parts[1].zfill(2)}-{parts[2].zfill(2)}"
        else:
            return ""
    return ""

def enrich_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        # подготовим пустые колонки даже для пустого df
        cols = [
            "carrier_name","route_code","transit_time_days","departure_frequency",
            "valid_from","valid_to","sailing_date","eta","incoterms","tax_rate",
            "extra_charges","security","remarks"
        ]
        for c in cols:
            df[c] = ""
        return df

    out = df.copy()
    
    def _extract_validity(text: str):
        if not text:
            return "", ""
        
        # Ищем все форматы Validity
        # Регулярка для разных форматов дат
        m = re.search(
            r'Validity:\s*([\d.\-]+)\s*-?\s*([\d.\-]*)?', 
            str(text), 
            re.IGNORECASE
        )
        if m:
            date1 = normalize_date(m.group(1))
            #print(m.group(1), date1)
            date2 = normalize_date(m.group(2)) if m.group(2) else date1
            return date1, date2
        return "", ""

    # Применяем новую функцию к колонкам
    cond_series = out["customs"] if "customs" in out.columns else pd.Series("" * len(out), index=out.index)
    
    # Извлекаем даты
    dates = cond_series.apply(_extract_validity)
    out["valid_from"] = dates.apply(lambda x: x[0])
    out["valid_to"] = dates.apply(lambda x: x[1])
    
    # carrier_name: берем из явного поля, если есть; иначе по company/условиям
    if "carrier_name" not in out.columns:
        out["carrier_name"] = ""

    # route_code: генерируем как POL–POD (берем только города до запятой)
    def _route_code(row):
        sp = str(row.get("start_point", "")).split(",")[0].strip()
        ep = str(row.get("end_point", "")).split(",")[0].strip()
        return f"{sp}–{ep}" if sp and ep else ""
    out["route_code"] = out.apply(_route_code, axis=1)

    # transit_time_days: нет явных данных — оставляем пусто (или 0)
    out["transit_time_days"] = ""

    # departure_frequency: нет явных данных — пусто
    out["departure_frequency"] = ""

    # valid_from / valid_to: извлечь из conditions, если упоминается Validity: YYYY-MM-DD..YYYY-MM-DD
    def _extract_valid_from(text: str):
        if not text:
            return ""
        m = re.search(r"Validity[:\s]*([0-9]{4}-[0-9]{2}-[0-9]{2})", str(text))
        return m.group(1) if m else ""
    def _extract_valid_to(text: str):
        if not text:
            return ""
        m = re.search(r"to[:\s]*([0-9]{4}-[0-9]{2}-[0-9]{2})", str(text), re.IGNORECASE)
        return m.group(1) if m else ""
    cond_series = out["conditions"] if "conditions" in out.columns else pd.Series([""] * len(out), index=out.index)
    out["valid_from"] = cond_series.apply(_extract_valid_from)
    out["valid_to"] = cond_series.apply(_extract_valid_to)

    # sailing_date: берем из departure_dates, если есть дата-строка; иначе пусто
    def _sailing_date(val):
        v = str(val).strip()
        # грубая эвристика: брать как есть
        return v if v and v.lower() != "nan" else ""
    dep_series = out["departure_dates"] if "departure_dates" in out.columns else pd.Series([""] * len(out), index=out.index)
    out["sailing_date"] = dep_series.apply(_sailing_date)

    # eta: если есть sailing_date и transit_time_days (число), можно посчитать, но т.к. transit пуст, оставим пусто
    out["eta"] = ""

    # incoterms: в тарифах не указан — пусто
    out["incoterms"] = ""

    # tax_rate: по умолчанию пусто (если RUB и явно встречается НДС в conditions — можно извлечь, пока пропустим)
    out["tax_rate"] = ""

    # extra_charges: извлечь из conditions частично (например PICKUP FEE, CHARGES), склеим найденные
    def _extra(text: str):
        t = str(text)
        parts = []
        m = re.search(r"PICKUP FEE[:\s]*([^\n]+)", t, re.IGNORECASE)
        if m:
            parts.append(f"PICKUP FEE:{m.group(1).strip()}")
        # уже есть отдельные сборы в Torgmoll — они в conditions строками 'NAME: value.'; можно вытянуть все пары с двоеточием
        for line in t.splitlines():
            if ":" in line and "PICKUP FEE" not in line.upper() and "Route" not in line and "Validity" not in line:
                parts.append(line.strip().rstrip("."))
        return "; ".join(dict.fromkeys([p for p in parts if p]))
    out["extra_charges"] = cond_series.apply(_extra)

    # security: если в conditions присутствует 'Охрана' или 'ВОХР'
    def _security(text: str):
        t = str(text).upper()
        if "ОХРАН" in t or "ВОХР" in t:
            return "ВОХР"
        return ""
    out["security"] = cond_series.apply(_security)

    # remarks: попытаемся извлечь хвосты из conditions после 'Remarks:' или строки с 'via'
    def _remarks(text: str):
        t = str(text)
        m = re.search(r"Remarks[:\s]*(.*)", t, re.IGNORECASE)
        if m:
            return m.group(1).strip()
        m2 = re.search(r"via\s+([A-Za-zА-Яа-я\-\s]+)", t)
        return f"via {m2.group(1).strip()}" if m2 else ""
    out["remarks"] = cond_series.apply(_remarks)

    return out

#df_all = enrich_dataframe(df_all)

#print(df_TransContainer)
print("--------------------------------")
#print(df_Mohill)
'''for item in df_RusTrans:
    
    print(item)'''
print("--------------------------------")
#print(MarmedContainer.head())
print("--------------------------------")
#print(HS_CHINA_LIMITED)
print("--------------------------------")
#print(df_all)
print("--------------------------------")
#print(df_Torgmoll)
#print(df_Mohill)
'''
with pd.ExcelWriter("tariff_analysis_TransContainer.xlsx") as writer:
    df_TransContainer.to_excel(writer, sheet_name="Raw Data", index=False)

with pd.ExcelWriter("tariff_analysis_RusTrans.xlsx") as writer:
    df_RusTrans.to_excel(writer, sheet_name="Raw Data", index=False)

with pd.ExcelWriter("tariff_analysis_Marmed_container.xlsx") as writer:
    df_MarmedContainer.to_excel(writer, sheet_name="Raw Data", index=False)

with pd.ExcelWriter("tariff_analysis_HS_CHINA_LIMITED.xlsx") as writer:
    df_HS_CHINA_LIMITED.to_excel(writer, sheet_name="Raw Data", index=False)

with pd.ExcelWriter("tariff_analysis_Torgmoll.xlsx") as writer:
    df_Torgmoll.to_excel(writer, sheet_name="Raw Data", index=False)

with pd.ExcelWriter("tariff_analysis_Mohill.xlsx") as writer:
    df_Mohill.to_excel(writer, sheet_name="Raw Data", index=False)
'''
'''
# Сохраняем все в Excel
with pd.ExcelWriter("tariff_analysis.xlsx") as writer:
    df_all.to_excel(writer, sheet_name="Raw Data", index=False)
'''
# =============================
# Генерация JSON по компаниям
# =============================

def _sanitize_filename(name: str) -> str:
    """Приводит строку к безопасному имени файла для Windows."""
    forbidden = '<>:"/\\|?*'
    result = name
    for ch in forbidden:
        result = result.replace(ch, "_")
    return result.strip()

def _to_number_or_zero(value):
    try:
        if value is None or (isinstance(value, float) and np.isnan(value)):
            return 0
        # Некоторые поля приходят строками с пробелами/знаками валют
        if isinstance(value, str):
            v = value.replace(" ", "").replace(",", ".")
            # убрать все, кроме цифр, точки и знака минуса
            v = re.sub(r"[^0-9.\-]", "", v)
            return float(v) if v not in ("", ".", "-") else 0
        return float(value)
    except Exception:
        return 0

def _to_str_or_empty(value):
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return ""
    return str(value)

def generate_company_jsons():
    companies_path = os.path.join(os.path.dirname(__file__), "companies.json")
    out_dir = os.path.join(os.path.dirname(__file__), "companies_json")
    os.makedirs(out_dir, exist_ok=True)

    # Читаем список компаний, определяем порядковые ID (1..N)
    with open(companies_path, "r", encoding="utf-8") as f:
        companies = json.load(f)
    name_to_id = {c["name"]: str(i + 1) for i, c in enumerate(companies)}

    # Карта: название компании -> соответствующий DataFrame
    company_to_df = {
        "ТрансКонтейнер": df_TransContainer,
        "РусТранс Групп": df_RusTrans,
        "Мармед - Контейнерное Агенство": df_MarmedContainer,
        "HS CHINA LIMITED": df_HS_CHINA_LIMITED,
        "Torgmoll": df_Torgmoll,
        "Mohill Rus": df_Mohill,
    }

    for company_name, df in company_to_df.items():
        transport_company_id = name_to_id.get(company_name, "0")
        segments = []
        if df is not None and not df.empty:
            for _, row in df.iterrows():
                segments.append({
                    "start_point": _to_str_or_empty(row.get("start_point", "")),
                    "end_point": _to_str_or_empty(row.get("end_point", "")),
                    "final_destination": _to_str_or_empty(row.get("final_destination", "")),
                    "weight_limit": _to_number_or_zero(row.get("weight_limit", 0)),
                    "cost": _to_number_or_zero(row.get("cost", 0)),
                    "currency": _to_str_or_empty(row.get("currency", "USD")) or "USD",
                    "duration": 0,
                    "container_type": _to_str_or_empty(row.get("container_type", "20DC")) or "20DC",
                    "transport_type": _to_str_or_empty(row.get("transport_type", "rail")) or "rail",
                    "departure_dates": {},
                    "conditions": _to_str_or_empty(row.get("conditions", "")),
                    "border_point": "",
                    "customs": "",
                })
        payload = {
            "transport_company_id": transport_company_id,
            "segments": segments,
        }

        file_name = f"{_sanitize_filename(company_name)}.json"
        file_path = os.path.join(out_dir, file_name)
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

#generate_company_jsons()